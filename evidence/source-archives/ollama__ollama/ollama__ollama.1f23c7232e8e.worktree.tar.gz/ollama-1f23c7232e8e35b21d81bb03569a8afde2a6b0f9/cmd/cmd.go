package cmd

import (
	"bufio"
	"bytes"
	"context"
	"crypto/ed25519"
	"crypto/rand"
	"encoding/json"
	"encoding/pem"
	"errors"
	"fmt"
	"io"
	"log"
	"log/slog"
	"math"
	"net"
	"net/http"
	"os"
	"os/signal"
	"path"
	"path/filepath"
	"runtime"
	"slices"
	"sort"
	"strconv"
	"strings"
	"sync/atomic"
	"syscall"
	"time"

	"github.com/containerd/console"
	"github.com/mattn/go-runewidth"
	"github.com/olekukonko/tablewriter"
	"github.com/pkg/browser"
	"github.com/spf13/cobra"
	"golang.org/x/crypto/ssh"
	"golang.org/x/sync/errgroup"
	"golang.org/x/term"

	"github.com/ollama/ollama/api"
	"github.com/ollama/ollama/cmd/config"
	"github.com/ollama/ollama/cmd/launch"
	"github.com/ollama/ollama/cmd/tui"
	"github.com/ollama/ollama/create"
	"github.com/ollama/ollama/discover"
	"github.com/ollama/ollama/envconfig"
	"github.com/ollama/ollama/format"
	"github.com/ollama/ollama/internal/modelref"
	"github.com/ollama/ollama/logutil"
	"github.com/ollama/ollama/manifest"
	"github.com/ollama/ollama/mlxrunner"
	"github.com/ollama/ollama/parser"
	"github.com/ollama/ollama/progress"
	"github.com/ollama/ollama/readline"
	"github.com/ollama/ollama/server"
	"github.com/ollama/ollama/types/model"
	"github.com/ollama/ollama/types/syncmap"
	"github.com/ollama/ollama/version"
)

func init() {
	// Override default selectors to use Bubbletea TUI instead of raw terminal I/O.
	launch.DefaultSingleSelector = func(title string, items []launch.SelectionItem, current string) (string, error) {
		return runTUISingleSelector(title, items, current, nil)
	}

	launch.DefaultSingleSelectorWithUpdates = func(title string, items []launch.SelectionItem, current string, updates <-chan []launch.SelectionItem) (string, error) {
		return runTUISingleSelector(title, items, current, updates)
	}

	launch.DefaultMultiSelector = func(title string, items []launch.SelectionItem, preChecked []string) ([]string, error) {
		return runTUIMultiSelector(title, items, preChecked, nil)
	}

	launch.DefaultMultiSelectorWithUpdates = func(title string, items []launch.SelectionItem, preChecked []string, updates <-chan []launch.SelectionItem) ([]string, error) {
		return runTUIMultiSelector(title, items, preChecked, updates)
	}

	launch.DefaultSignIn = func(modelName, signInURL string) (string, error) {
		userName, err := tui.RunSignIn(modelName, signInURL)
		if errors.Is(err, tui.ErrCancelled) {
			return "", launch.ErrCancelled
		}
		return userName, err
	}

	launch.DefaultConfirmPrompt = tui.RunConfirmWithOptions

	launch.DefaultSpinner = tui.RunSpinner
}

func runTUISingleSelector(title string, items []launch.SelectionItem, current string, updates <-chan []launch.SelectionItem) (string, error) {
	if !term.IsTerminal(int(os.Stdin.Fd())) || !term.IsTerminal(int(os.Stdout.Fd())) {
		return "", fmt.Errorf("model selection requires an interactive terminal; use --model to run in headless mode")
	}
	tuiItems := tui.ReorderItems(tui.ConvertItems(items))
	result, err := tui.SelectSingleWithUpdates(title, tuiItems, current, convertSelectionItemUpdates(updates))
	if errors.Is(err, tui.ErrCancelled) {
		return "", launch.ErrCancelled
	}
	return result, err
}

func runTUIMultiSelector(title string, items []launch.SelectionItem, preChecked []string, updates <-chan []launch.SelectionItem) ([]string, error) {
	if !term.IsTerminal(int(os.Stdin.Fd())) || !term.IsTerminal(int(os.Stdout.Fd())) {
		return nil, fmt.Errorf("model selection requires an interactive terminal; use --model to run in headless mode")
	}
	tuiItems := tui.ReorderItems(tui.ConvertItems(items))
	result, err := tui.SelectMultipleWithUpdates(title, tuiItems, preChecked, convertSelectionItemUpdates(updates))
	if errors.Is(err, tui.ErrCancelled) {
		return nil, launch.ErrCancelled
	}
	return result, err
}

func convertSelectionItemUpdates(updates <-chan []launch.SelectionItem) <-chan []tui.SelectItem {
	if updates == nil {
		return nil
	}
	out := make(chan []tui.SelectItem, 1)
	go func() {
		defer close(out)
		for items := range updates {
			out <- tui.ReorderItems(tui.ConvertItems(items))
		}
	}()
	return out
}

const ConnectInstructions = "If your browser did not open, navigate to:\n    %s\n\n"

// ensureThinkingSupport emits a warning if the model does not advertise thinking support
func ensureThinkingSupport(ctx context.Context, client *api.Client, name, runner string) {
	if name == "" {
		return
	}
	resp, err := client.Show(ctx, &api.ShowRequest{Model: name, Runner: runner})
	if err != nil {
		return
	}
	if slices.Contains(resp.Capabilities, model.CapabilityThinking) {
		return
	}
	fmt.Fprintf(os.Stderr, "warning: model %q does not support thinking output\n", name)
}

func getModelfileName(cmd *cobra.Command) (string, error) {
	filename, _ := cmd.Flags().GetString("file")

	if filename == "" {
		filename = "Modelfile"
	}

	absName, err := filepath.Abs(filename)
	if err != nil {
		return "", err
	}

	_, err = os.Stat(absName)
	if err != nil {
		return "", err
	}

	return absName, nil
}

// isLocalhost returns true if the configured Ollama host is a loopback or unspecified address.
func isLocalhost() bool {
	host := envconfig.Host()
	h, _, _ := net.SplitHostPort(host.Host)
	if h == "localhost" {
		return true
	}
	ip := net.ParseIP(h)
	return ip != nil && (ip.IsLoopback() || ip.IsUnspecified())
}

func resolveCreateLocalModelDir(ref, filename string) string {
	if ref == "" || filepath.IsAbs(ref) || filename == "" {
		return ref
	}

	candidate := filepath.Join(filepath.Dir(filename), ref)
	if create.IsSafetensorsModelDir(candidate) {
		return candidate
	}

	return ref
}

func resolveCreateDraftDir(ref, filename string) (string, error) {
	if ref == "" {
		return "", nil
	}
	if filepath.IsAbs(ref) {
		if create.IsSafetensorsModelDir(ref) {
			return ref, nil
		}
		return "", fmt.Errorf("draft %s is not a supported safetensors model directory", ref)
	}
	if filename != "" {
		candidate := filepath.Join(filepath.Dir(filename), ref)
		if create.IsSafetensorsModelDir(candidate) {
			return candidate, nil
		}
	}

	return "", fmt.Errorf("DRAFT model references must be local safetensors directories for safetensors create: %s", ref)
}

func readCreateModelfile(cmd *cobra.Command) (*parser.Modelfile, string, error) {
	var reader io.Reader
	filename, err := getModelfileName(cmd)
	if errors.Is(err, os.ErrNotExist) || filename == "" {
		reader = strings.NewReader("FROM .\n")
	} else if err != nil {
		return nil, "", err
	} else {
		f, err := os.Open(filename)
		if err != nil {
			return nil, "", err
		}
		defer f.Close()
		reader = f
	}

	modelfile, err := parser.ParseFile(reader)
	if err != nil {
		return nil, "", err
	}
	return modelfile, filename, nil
}

func safetensorsCreateOptions(modelfile *parser.Modelfile, filename, modelName string) (createOptions, bool, error) {
	modelDir, mfConfig, err := configFromModelfile(modelfile)
	if err != nil {
		return createOptions{}, false, err
	}

	modelDir = resolveCreateLocalModelDir(modelDir, filename)
	isSafetensors := create.IsSafetensorsModelDir(modelDir)
	isBaseModelWithDraft := mfConfig.Draft != "" && !isSafetensors && create.IsSafetensorsLLMModel(modelDir)
	if !isSafetensors && !isBaseModelWithDraft {
		return createOptions{}, false, nil
	}

	if mfConfig.Draft != "" {
		draftDir, err := resolveCreateDraftDir(mfConfig.Draft, filename)
		if err != nil {
			if isSafetensors {
				return createOptions{}, false, err
			}
			// Existing safetensors models may still use a GGUF DRAFT layer;
			// leave that combination on the standard create path.
			return createOptions{}, false, nil
		}
		mfConfig.Draft = draftDir
	}

	var modelCount, draftCount int
	for _, command := range modelfile.Commands {
		switch command.Name {
		case "model":
			modelCount++
		case "draft":
			draftCount++
		}
	}
	if modelCount != 1 {
		return createOptions{}, false, errors.New("safetensors imports require exactly one FROM source")
	}
	if draftCount > 1 {
		return createOptions{}, false, errors.New("safetensors imports support at most one DRAFT source")
	}

	return createOptions{
		ModelName: modelName,
		ModelDir:  modelDir,
		Modelfile: mfConfig,
	}, true, nil
}

var (
	errAdaptersUnsupported = errors.New("LoRA adapters are no longer supported")
	errForceLocalOnly      = errors.New("--force is only supported for local MLX safetensors imports")
	errTypicalPDeprecated  = errors.New("typical_p is deprecated and cannot be set as a model parameter; pass it as a request option instead")
)

// createSafetensorsModel imports in-process when the server is local and
// otherwise uploads the source files for the server to import.
func createSafetensorsModel(cmd *cobra.Command, args []string, opts createOptions, p *progress.Progress) error {
	if !envconfig.CreateRemote() && isLocalhost() {
		return createModel(cmd.Context(), opts, p)
	}
	if opts.Force {
		return errForceLocalOnly
	}
	if err := checkServerHeartbeat(cmd, args); err != nil {
		return err
	}
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}
	return createModelRemote(cmd.Context(), client, opts, p)
}

func CreateHandler(cmd *cobra.Command, args []string) error {
	p := progress.NewProgress(os.Stderr)
	defer p.Stop()

	// Validate model name early to fail fast
	modelName := args[0]
	name := model.ParseName(modelName)
	if !name.IsValid() {
		return fmt.Errorf("invalid model name: %s", modelName)
	}

	list, _ := cmd.Flags().GetStringSlice("combine")
	if len(list) > 0 {
		if quantize, _ := cmd.Flags().GetString("quantize"); quantize != "" {
			return errors.New("--combine cannot be used with --quantize")
		}
		if cmd.Flags().Changed("file") {
			return errors.New("--combine cannot be used with --file")
		}

		client, err := api.ClientFromEnvironment()
		if err != nil {
			return err
		}

		req := &api.CreateRequest{
			Model: modelName,
			List:  list,
		}

		status := "creating manifest list"
		spinner := progress.NewSpinner(status)
		p.Add(status, spinner)

		fn := func(resp api.ProgressResponse) error {
			if status != resp.Status {
				spinner.Stop()
				status = resp.Status
				spinner = progress.NewSpinner(status)
				p.Add(status, spinner)
			}
			return nil
		}

		return client.Create(cmd.Context(), req, fn)
	}

	draftQuantize, _ := cmd.Flags().GetString("draft-quantize")
	quantize, _ := cmd.Flags().GetString("quantize")
	force, _ := cmd.Flags().GetBool("force")
	modelfile, filename, err := readCreateModelfile(cmd)
	if err != nil {
		return err
	}
	if slices.ContainsFunc(modelfile.Commands, func(c parser.Command) bool { return c.Name == "adapter" }) {
		return errAdaptersUnsupported
	}
	if slices.ContainsFunc(modelfile.Commands, func(c parser.Command) bool { return c.Name == "typical_p" }) {
		return errTypicalPDeprecated
	}

	opts, isSafetensorsCreate, err := safetensorsCreateOptions(modelfile, filename, modelName)
	if err != nil {
		return err
	}
	if isSafetensorsCreate {
		opts.Quantize = quantize
		opts.DraftQuantize = draftQuantize
		opts.Force = force
		return createSafetensorsModel(cmd, args, opts, p)
	}
	if quantize != "" {
		return errors.New("create-time quantization is only supported for safetensors imports; quantize GGUF models before importing")
	}
	if force {
		return errForceLocalOnly
	}

	// Standard Modelfile + API path
	status := "gathering model components"
	spinner := progress.NewSpinner(status)
	p.Add(status, spinner)

	req, err := modelfile.CreateRequest(filepath.Dir(filename))
	if err != nil {
		return err
	}
	spinner.Stop()

	req.Model = modelName
	if draftQuantize != "" {
		if len(req.DraftFiles) == 0 {
			return errors.New("--draft-quantize requires a DRAFT model")
		}
		return errors.New("draft quantization during create is only supported for safetensors imports; quantize GGUF draft models before importing")
	}
	if err := checkServerHeartbeat(cmd, args); err != nil {
		return err
	}
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}
	// A FROM-only create has nothing to transfer, so skip the store probe.
	local := len(req.Files)+len(req.DraftFiles) > 0 && sharedBlobStore(cmd.Context(), client)

	var g errgroup.Group
	g.SetLimit(max(runtime.GOMAXPROCS(0)-1, 1))

	files := syncmap.NewSyncMap[string, string]()
	fileNames := createRequestFileNames(req.Files)
	for f, digest := range req.Files {
		g.Go(func() error {
			if _, err := createBlob(cmd, client, f, digest, p, local); err != nil {
				return err
			}

			files.Store(fileNames[f], digest)
			return nil
		})
	}

	draftFiles := syncmap.NewSyncMap[string, string]()
	draftFileNames := createRequestFileNames(req.DraftFiles)
	for f, digest := range req.DraftFiles {
		g.Go(func() error {
			if _, err := createBlob(cmd, client, f, digest, p, local); err != nil {
				return err
			}

			draftFiles.Store(draftFileNames[f], digest)
			return nil
		})
	}

	if err := g.Wait(); err != nil {
		return err
	}

	req.Files = files.Items()
	req.DraftFiles = draftFiles.Items()

	bars := make(map[string]*progress.Bar)
	fn := func(resp api.ProgressResponse) error {
		if resp.Digest != "" {
			bar, ok := bars[resp.Digest]
			if !ok {
				msg := resp.Status
				if msg == "" {
					msg = fmt.Sprintf("pulling %s...", resp.Digest[7:19])
				}
				bar = progress.NewBar(msg, resp.Total, resp.Completed)
				bars[resp.Digest] = bar
				p.Add(resp.Digest, bar)
			}

			bar.Set(resp.Completed)
		} else if status != resp.Status {
			spinner.Stop()

			status = resp.Status
			spinner = progress.NewSpinner(status)
			p.Add(status, spinner)
		}

		return nil
	}

	if err := client.Create(cmd.Context(), req, fn); err != nil {
		if strings.Contains(err.Error(), "path or Modelfile are required") {
			return fmt.Errorf("the ollama server must be updated to use `ollama create` with this client")
		}
		return err
	}

	return nil
}

func createRequestFileNames(files map[string]string) map[string]string {
	names := make(map[string]string, len(files))
	root, ok := commonFileRoot(files)
	for f := range files {
		name := filepath.Base(f)
		if ok {
			abs, err := filepath.Abs(f)
			if err == nil {
				if rel, err := filepath.Rel(root, abs); err == nil && rel != "." && rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)) {
					name = rel
				}
			}
		}
		names[f] = path.Clean(filepath.ToSlash(name))
	}
	return names
}

func commonFileRoot(files map[string]string) (string, bool) {
	if len(files) < 2 {
		return "", false
	}

	var root string
	var volume string
	for f := range files {
		abs, err := filepath.Abs(f)
		if err != nil {
			return "", false
		}
		if nextVolume := filepath.VolumeName(abs); volume == "" {
			volume = nextVolume
		} else if !strings.EqualFold(volume, nextVolume) {
			return "", false
		}

		dir := filepath.Dir(abs)
		if root == "" {
			root = dir
			continue
		}

		for {
			rel, err := filepath.Rel(root, dir)
			if err == nil && (rel == "." || (rel != ".." && !strings.HasPrefix(rel, ".."+string(filepath.Separator)))) {
				break
			}

			parent := filepath.Dir(root)
			if parent == root {
				return "", false
			}
			root = parent
		}
	}

	return root, root != ""
}

// sharedBlobStore reports whether the server reads blobs from this process's
// models directory, in which case create can write blobs there directly
// instead of streaming them over HTTP. A throwaway blob is written and the
// server asked whether it can see it, so a server with a different
// OLLAMA_MODELS (a systemd-managed install, for example) falls back to upload.
func sharedBlobStore(ctx context.Context, client *api.Client) bool {
	if envconfig.CreateRemote() || !isLocalhost() {
		return false
	}
	probe := make([]byte, 32)
	if _, err := rand.Read(probe); err != nil {
		return false
	}
	layer, err := manifest.NewLayer(bytes.NewReader(probe), "")
	if err != nil {
		return false
	}
	defer func() {
		if blob, err := manifest.BlobsPath(layer.Digest); err == nil {
			os.Remove(blob)
		}
	}()
	exists, err := client.HeadBlob(ctx, layer.Digest)
	return err == nil && exists
}

// createBlob makes the file at path available to the server under digest,
// writing it straight into the shared blob store when local is set and
// uploading it otherwise. Blobs the server already has are skipped.
func createBlob(cmd *cobra.Command, client *api.Client, path string, digest string, p *progress.Progress, local bool) (string, error) {
	if exists, err := client.HeadBlob(cmd.Context(), digest); err != nil {
		return "", err
	} else if exists {
		return digest, nil
	}

	realPath, err := filepath.EvalSymlinks(path)
	if err != nil {
		return "", err
	}

	bin, err := os.Open(realPath)
	if err != nil {
		return "", err
	}
	defer bin.Close()

	// Get file info to retrieve the size
	fileInfo, err := bin.Stat()
	if err != nil {
		return "", err
	}
	fileSize := fileInfo.Size()

	var pw progressWriter
	status := fmt.Sprintf("copying file %s 0%%", digest)
	spinner := progress.NewSpinner(status)
	p.Add(status, spinner)
	defer spinner.Stop()

	done := make(chan struct{})
	defer close(done)

	go func() {
		ticker := time.NewTicker(60 * time.Millisecond)
		defer ticker.Stop()
		for {
			select {
			case <-ticker.C:
				spinner.SetMessage(fmt.Sprintf("copying file %s %d%%", digest, int(100*pw.n.Load()/fileSize)))
			case <-done:
				spinner.SetMessage(fmt.Sprintf("copying file %s 100%%", digest))
				return
			}
		}
	}()

	reader := io.TeeReader(bin, &pw)
	if local {
		layer, err := manifest.NewLayer(reader, "")
		if err != nil {
			return "", err
		}
		if layer.Digest != digest {
			return "", fmt.Errorf("%s changed during create: expected digest %s, got %s", path, digest, layer.Digest)
		}
		return digest, nil
	}
	if err := client.CreateBlob(cmd.Context(), digest, reader); err != nil {
		return "", err
	}
	return digest, nil
}

type progressWriter struct {
	n atomic.Int64
}

func (w *progressWriter) Write(p []byte) (n int, err error) {
	w.n.Add(int64(len(p)))
	return len(p), nil
}

func loadOrUnloadModel(cmd *cobra.Command, opts *runOptions) error {
	p := progress.NewProgress(os.Stderr)
	defer p.StopAndClear()

	spinner := progress.NewSpinner("")
	p.Add("", spinner)

	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	requestedCloud := modelref.HasExplicitCloudSource(opts.Model)

	if info, err := client.Show(cmd.Context(), &api.ShowRequest{Model: opts.Model, Runner: opts.Runner}); err != nil {
		return err
	} else if info.RemoteHost != "" || requestedCloud {
		// Cloud model, no need to load/unload

		isCloud := requestedCloud || strings.HasPrefix(info.RemoteHost, "https://ollama.com")

		// Check if user is signed in for ollama.com cloud models
		if isCloud {
			if _, err := client.Whoami(cmd.Context()); err != nil {
				return err
			}
		}

		if opts.ShowConnect {
			p.StopAndClear()
			remoteModel := info.RemoteModel
			if remoteModel == "" {
				remoteModel = opts.Model
			}
			if isCloud {
				fmt.Fprintf(os.Stderr, "Connecting to '%s' on 'ollama.com' ⚡\n", remoteModel)
			} else {
				fmt.Fprintf(os.Stderr, "Connecting to '%s' on '%s'\n", remoteModel, info.RemoteHost)
			}
		}

		return nil
	}

	req := &api.GenerateRequest{
		Model:     opts.Model,
		Runner:    opts.Runner,
		KeepAlive: opts.KeepAlive,

		// pass Think here so we fail before getting to the chat prompt if the model doesn't support it
		Think: opts.Think,
	}

	return client.Generate(cmd.Context(), req, func(r api.GenerateResponse) error {
		return nil
	})
}

func StopHandler(cmd *cobra.Command, args []string) error {
	opts := &runOptions{
		Model:     args[0],
		KeepAlive: &api.Duration{Duration: 0},
	}
	if err := loadOrUnloadModel(cmd, opts); err != nil {
		if strings.Contains(err.Error(), "not found") {
			return fmt.Errorf("couldn't find model \"%s\" to stop", args[0])
		}
		return err
	}
	return nil
}

func generateEmbedding(cmd *cobra.Command, modelName, input string, keepAlive *api.Duration, truncate *bool, dimensions int) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	req := &api.EmbedRequest{
		Model: modelName,
		Input: input,
	}
	if keepAlive != nil {
		req.KeepAlive = keepAlive
	}
	if truncate != nil {
		req.Truncate = truncate
	}
	if dimensions > 0 {
		req.Dimensions = dimensions
	}

	resp, err := client.Embed(cmd.Context(), req)
	if err != nil {
		return err
	}

	if len(resp.Embeddings) == 0 {
		return errors.New("no embeddings returned")
	}

	output, err := json.Marshal(resp.Embeddings[0])
	if err != nil {
		return err
	}
	fmt.Println(string(output))

	return nil
}

// TODO(parthsareen): consolidate with TUI signin flow
func handleCloudAuthorizationError(err error) bool {
	var authErr api.AuthorizationError
	if errors.As(err, &authErr) && authErr.StatusCode == http.StatusUnauthorized {
		fmt.Printf("You need to be signed in to Ollama to run Cloud models.\n\n")
		if authErr.SigninURL != "" {
			fmt.Printf(ConnectInstructions, authErr.SigninURL)
		}
		return true
	}

	return false
}

// TEMP(drifkin): To match legacy `ollama run some-model:cloud` behavior, we
// best-effort pull cloud stub files for any explicit cloud source models.
// Remove this once `/api/tags` is cloud-aware.
func ensureCloudStub(ctx context.Context, client *api.Client, modelName string) {
	if !modelref.HasExplicitCloudSource(modelName) {
		return
	}

	normalizedName, _, err := modelref.NormalizePullName(modelName)
	if err != nil {
		slog.Warn("failed to normalize pull name", "model", modelName, "error", err, "normalizedName", normalizedName)
		return
	}

	listResp, err := client.List(ctx)
	if err != nil {
		slog.Warn("failed to list models", "error", err)
		return
	}

	if hasListedModelName(listResp.Models, modelName) || hasListedModelName(listResp.Models, normalizedName) {
		return
	}

	logutil.Trace("pulling cloud stub", "model", modelName, "normalizedName", normalizedName)
	err = client.Pull(ctx, &api.PullRequest{
		Model: normalizedName,
	}, func(api.ProgressResponse) error {
		return nil
	})
	if err != nil {
		slog.Warn("failed to pull cloud stub", "model", modelName, "error", err)
	}
}

func hasListedModelName(models []api.ListModelResponse, name string) bool {
	for _, m := range models {
		if strings.EqualFold(m.Name, name) || strings.EqualFold(m.Model, name) {
			return true
		}
	}
	return false
}

// showOrPullModel returns model info for name, pulling the model if it isn't
// available locally. If the pull finds no default tag but a ":cloud" tag
// exists, the user may be offered the cloud model instead (see
// pullWithCloudSuggestion), in which case the returned name is the cloud
// name the caller should continue with. verb is the user-facing command
// ("run" or "pull") used in hint text.
func showOrPullModel(cmd *cobra.Command, client *api.Client, name, runner string, insecure bool, verb string) (*api.ShowResponse, string, error) {
	info, err := client.Show(cmd.Context(), &api.ShowRequest{Model: name, Runner: runner})
	if err == nil {
		return info, name, nil
	}

	var se api.StatusError
	if !errors.As(err, &se) || se.StatusCode != http.StatusNotFound || modelref.HasExplicitCloudSource(name) {
		return nil, name, err
	}

	resolved, err := pullWithCloudSuggestion(cmd.Context(), client, name, runner, insecure, verb)
	if err != nil {
		return nil, name, err
	}

	info, err = client.Show(cmd.Context(), &api.ShowRequest{Model: resolved, Runner: runner})
	return info, resolved, err
}

func RunHandler(cmd *cobra.Command, args []string) error {
	interactive := true

	opts := runOptions{
		Model:       args[0],
		WordWrap:    os.Getenv("TERM") == "xterm-256color",
		Options:     map[string]any{},
		ShowConnect: true,
	}

	if flag := cmd.Flags().Lookup("runner"); flag != nil {
		runner, err := cmd.Flags().GetString("runner")
		if err != nil {
			return err
		}
		opts.Runner = runner
	}

	format, err := cmd.Flags().GetString("format")
	if err != nil {
		return err
	}
	opts.Format = format

	thinkFlag := cmd.Flags().Lookup("think")
	if thinkFlag.Changed {
		thinkStr, err := cmd.Flags().GetString("think")
		if err != nil {
			return err
		}

		// Handle different values for --think
		switch thinkStr {
		case "", "true":
			// --think or --think=true
			opts.Think = &api.ThinkValue{Value: true}
		case "false":
			opts.Think = &api.ThinkValue{Value: false}
		default:
			opts.Think = &api.ThinkValue{Value: thinkStr}
		}
	} else {
		opts.Think = nil
	}
	hidethinking, err := cmd.Flags().GetBool("hidethinking")
	if err != nil {
		return err
	}
	opts.HideThinking = hidethinking

	keepAlive, err := cmd.Flags().GetString("keepalive")
	if err != nil {
		return err
	}
	if keepAlive != "" {
		d, err := time.ParseDuration(keepAlive)
		if err != nil {
			return err
		}
		opts.KeepAlive = &api.Duration{Duration: d}
	}

	prompts := args[1:]
	stdinPiped := !term.IsTerminal(int(os.Stdin.Fd()))
	if stdinPiped {
		opts.ShowConnect = false
		opts.WordWrap = false
		interactive = false
	}
	if len(prompts) > 0 {
		interactive = false
	}
	// Be quiet if we're redirecting to a pipe or file
	if !term.IsTerminal(int(os.Stdout.Fd())) {
		interactive = false
	}

	nowrap, err := cmd.Flags().GetBool("nowordwrap")
	if err != nil {
		return err
	}
	// Wrapping rewrites the line with cursor escapes, which only a terminal
	// can interpret; piped or redirected output stays plain text.
	opts.WordWrap = !nowrap && term.IsTerminal(int(os.Stdout.Fd()))

	// Fill out the rest of the options based on information about the
	// model.
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	insecure, err := cmd.Flags().GetBool("insecure")
	if err != nil {
		return err
	}

	info, name, err := showOrPullModel(cmd, client, args[0], opts.Runner, insecure, "run")
	if err != nil {
		if handleCloudAuthorizationError(err) {
			return nil
		}
		return err
	}
	// The model may have been resolved to a different name (e.g. its ":cloud"
	// variant), so make sure downstream requests use it.
	opts.Model = name

	ensureCloudStub(cmd.Context(), client, name)

	opts.Think, err = inferThinkingOption(&info.Capabilities, &opts, thinkFlag.Changed)
	if err != nil {
		return err
	}

	applyShowResponseToRunOptions(&opts, info)

	// prepend stdin to the prompt if provided; speech models read it as it
	// arrives instead. Models that also chat speak when --voice is given and
	// chat otherwise.
	speech := slices.Contains(info.Capabilities, model.CapabilitySpeech) &&
		(!slices.Contains(info.Capabilities, model.CapabilityCompletion) || cmd.Flags().Changed("voice"))
	if stdinPiped && !speech {
		in, err := io.ReadAll(os.Stdin)
		if err != nil {
			return err
		}

		// Only prepend stdin content if it's not empty
		stdinContent := string(in)
		if len(stdinContent) > 0 {
			prompts = append([]string{stdinContent}, prompts...)
		}
	}
	opts.Prompt = strings.Join(prompts, " ")

	if slices.Contains(info.Capabilities, model.CapabilityDecision) {
		return runDecision(cmd, opts, interactive)
	}
	if cmd.Flags().Changed("ask") {
		return fmt.Errorf("%s is not a decision model, so it can't answer --ask questions", name)
	}
	if cmd.Flags().Changed("voice") && !speech {
		return fmt.Errorf("%s is not a speech model, so it can't use --voice", name)
	}

	// Check if this is an embedding model
	isEmbeddingModel := slices.Contains(info.Capabilities, model.CapabilityEmbedding)

	// If it's an embedding model, handle embedding generation
	if isEmbeddingModel {
		if opts.Prompt == "" {
			return errors.New("embedding models require input text. Usage: ollama run " + name + " \"your text here\"")
		}

		// Get embedding-specific flags
		var truncate *bool
		if truncateFlag, err := cmd.Flags().GetBool("truncate"); err == nil && cmd.Flags().Changed("truncate") {
			truncate = &truncateFlag
		}

		dimensions, err := cmd.Flags().GetInt("dimensions")
		if err != nil {
			return err
		}

		return generateEmbedding(cmd, name, opts.Prompt, opts.KeepAlive, truncate, dimensions)
	}

	if speech {
		voice, err := cmd.Flags().GetString("voice")
		if err != nil {
			return err
		}
		var input io.Reader
		if stdinPiped {
			input = os.Stdin
		}
		return runSpeech(cmd.Context(), name, voice, opts.Prompt, input, interactive)
	}

	if slices.Contains(info.Capabilities, model.CapabilityImage) {
		return errors.New("image generation models are not currently supported")
	}

	if interactive {
		if err := loadOrUnloadModel(cmd, &opts); err != nil {
			var sErr api.AuthorizationError
			if errors.As(err, &sErr) && sErr.StatusCode == http.StatusUnauthorized {
				fmt.Printf("You need to be signed in to Ollama to run Cloud models.\n\n")

				if sErr.SigninURL != "" {
					fmt.Printf(ConnectInstructions, sErr.SigninURL)
				}
				return nil
			}
			return err
		}

		for _, msg := range info.Messages {
			switch msg.Role {
			case "user":
				fmt.Printf(">>> %s\n", msg.Content)
			case "assistant":
				state := &displayResponseState{}
				displayResponse(msg.Content, opts.WordWrap, state)
				fmt.Println()
				fmt.Println()
			}
		}

		return generateInteractive(cmd, opts)
	}
	if err := generate(cmd, opts); err != nil {
		if handleCloudAuthorizationError(err) {
			return nil
		}
		return err
	}
	return nil
}

func SigninHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	user, err := client.Whoami(cmd.Context())
	if err != nil {
		var aErr api.AuthorizationError
		if errors.As(err, &aErr) && aErr.StatusCode == http.StatusUnauthorized {
			fmt.Println("You need to be signed in to Ollama to run Cloud models.")
			fmt.Println()

			if aErr.SigninURL != "" {
				_ = browser.OpenURL(aErr.SigninURL)
				fmt.Printf(ConnectInstructions, aErr.SigninURL)
			}
			return nil
		}
		return err
	}

	if user != nil && user.Name != "" {
		fmt.Printf("You are already signed in as user '%s'\n", user.Name)
		fmt.Println()
		return nil
	}

	return nil
}

func SignoutHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	err = client.Signout(cmd.Context())
	if err != nil {
		var aErr api.AuthorizationError
		if errors.As(err, &aErr) && aErr.StatusCode == http.StatusUnauthorized {
			fmt.Println("You are not signed in to ollama.com")
			fmt.Println()
			return nil
		} else {
			return err
		}
	}

	fmt.Println("You have signed out of ollama.com")
	fmt.Println()
	return nil
}

func PushHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	insecure, err := cmd.Flags().GetBool("insecure")
	if err != nil {
		return err
	}

	n := model.ParseName(args[0])
	if strings.HasSuffix(n.Host, ".ollama.ai") || strings.HasSuffix(n.Host, ".ollama.com") {
		_, err := client.Whoami(cmd.Context())
		if err != nil {
			var aErr api.AuthorizationError
			if errors.As(err, &aErr) && aErr.StatusCode == http.StatusUnauthorized {
				fmt.Println("You need to be signed in to push models to ollama.com.")
				fmt.Println()

				if aErr.SigninURL != "" {
					fmt.Printf(ConnectInstructions, aErr.SigninURL)
				}
				return nil
			}

			return err
		}
	}

	p := progress.NewProgress(os.Stderr)
	defer p.Stop()

	bars := make(map[string]*progress.Bar)
	var status string
	var spinner *progress.Spinner

	fn := func(resp api.ProgressResponse) error {
		if resp.Digest != "" {
			if spinner != nil {
				spinner.Stop()
			}

			bar, ok := bars[resp.Digest]
			if !ok {
				msg := resp.Status
				if msg == "" {
					msg = fmt.Sprintf("pushing %s...", resp.Digest[7:19])
				}
				bar = progress.NewBar(msg, resp.Total, resp.Completed)
				bars[resp.Digest] = bar
				p.Add(resp.Digest, bar)
			}

			bar.Set(resp.Completed)
		} else if status != resp.Status {
			if spinner != nil {
				spinner.Stop()
			}

			status = resp.Status
			spinner = progress.NewSpinner(status)
			p.Add(status, spinner)
		}

		return nil
	}

	request := api.PushRequest{Name: args[0], Insecure: insecure}

	if err := client.Push(cmd.Context(), &request, fn); err != nil {
		if spinner != nil {
			spinner.Stop()
		}
		errStr := strings.ToLower(err.Error())
		if strings.Contains(errStr, "access denied") || strings.Contains(errStr, "unauthorized") {
			return errors.New("you are not authorized to push to this namespace, create the model under a namespace you own")
		}
		return err
	}

	p.Stop()
	spinner.Stop()

	destination := n.String()
	if strings.HasSuffix(n.Host, ".ollama.ai") || strings.HasSuffix(n.Host, ".ollama.com") {
		destination = "https://ollama.com/" + strings.TrimSuffix(n.DisplayShortest(), ":latest")
	}
	fmt.Printf("\nYou can find your model at:\n\n")
	fmt.Printf("\t%s\n", destination)

	return nil
}

func ListHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	models, err := client.List(cmd.Context())
	if err != nil {
		return err
	}

	var data [][]string

	for _, m := range models.Models {
		if len(args) == 0 || strings.HasPrefix(strings.ToLower(m.Name), strings.ToLower(args[0])) {
			var size string
			if m.RemoteModel != "" {
				size = "-"
			} else {
				size = format.HumanBytes(m.Size)
			}

			data = append(data, []string{m.Name, m.Digest[:12], size, format.HumanTime(m.ModifiedAt, "Never")})
		}
	}

	table := tablewriter.NewWriter(os.Stdout)
	table.SetHeader([]string{"NAME", "ID", "SIZE", "MODIFIED"})
	table.SetHeaderAlignment(tablewriter.ALIGN_LEFT)
	table.SetAlignment(tablewriter.ALIGN_LEFT)
	table.SetHeaderLine(false)
	table.SetBorder(false)
	table.SetNoWhiteSpace(true)
	table.SetTablePadding("    ")
	table.AppendBulk(data)
	table.Render()

	return nil
}

func ListRunningHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	models, err := client.ListRunning(cmd.Context())
	if err != nil {
		return err
	}

	var data [][]string

	for _, m := range models.Models {
		if len(args) == 0 || strings.HasPrefix(m.Name, args[0]) {
			var procStr string
			switch {
			case m.SizeVRAM == 0:
				procStr = "100% CPU"
			case m.SizeVRAM == m.Size:
				procStr = "100% GPU"
			case m.SizeVRAM > m.Size || m.Size == 0:
				procStr = "Unknown"
			default:
				sizeCPU := m.Size - m.SizeVRAM
				cpuPercent := math.Round(float64(sizeCPU) / float64(m.Size) * 100)
				procStr = fmt.Sprintf("%d%%/%d%% CPU/GPU", int(cpuPercent), int(100-cpuPercent))
			}

			var until string
			delta := time.Since(m.ExpiresAt)
			if delta > 0 {
				until = "Stopping..."
			} else {
				until = format.HumanTime(m.ExpiresAt, "Never")
			}
			ctxStr := "-"
			if m.ContextLength > 0 {
				ctxStr = strconv.Itoa(m.ContextLength)
			}
			data = append(data, []string{m.Name, m.Digest[:12], format.HumanBytes(m.Size), procStr, ctxStr, m.Runner, until})
		}
	}

	table := tablewriter.NewWriter(os.Stdout)
	table.SetHeader([]string{"NAME", "ID", "SIZE", "PROCESSOR", "CONTEXT", "RUNNER", "UNTIL"})
	table.SetHeaderAlignment(tablewriter.ALIGN_LEFT)
	table.SetAlignment(tablewriter.ALIGN_LEFT)
	table.SetHeaderLine(false)
	table.SetBorder(false)
	table.SetNoWhiteSpace(true)
	table.SetTablePadding("    ")
	table.AppendBulk(data)
	table.Render()

	return nil
}

func DeleteHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	for _, arg := range args {
		// Unload the model if it's running before deletion
		if err := loadOrUnloadModel(cmd, &runOptions{
			Model:     arg,
			KeepAlive: &api.Duration{Duration: 0},
		}); err != nil {
			if !strings.Contains(strings.ToLower(err.Error()), "not found") {
				fmt.Fprintf(os.Stderr, "Warning: unable to stop model '%s'\n", arg)
			}
		}

		if err := client.Delete(cmd.Context(), &api.DeleteRequest{Name: arg}); err != nil {
			return err
		}
		fmt.Printf("deleted '%s'\n", arg)
	}
	return nil
}

func ShowHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	license, errLicense := cmd.Flags().GetBool("license")
	modelfile, errModelfile := cmd.Flags().GetBool("modelfile")
	parameters, errParams := cmd.Flags().GetBool("parameters")
	system, errSystem := cmd.Flags().GetBool("system")
	template, errTemplate := cmd.Flags().GetBool("template")
	verbose, errVerbose := cmd.Flags().GetBool("verbose")

	for _, boolErr := range []error{errLicense, errModelfile, errParams, errSystem, errTemplate, errVerbose} {
		if boolErr != nil {
			return errors.New("error retrieving flags")
		}
	}

	flagsSet := 0
	showType := ""

	if license {
		flagsSet++
		showType = "license"
	}

	if modelfile {
		flagsSet++
		showType = "modelfile"
	}

	if parameters {
		flagsSet++
		showType = "parameters"
	}

	if system {
		flagsSet++
		showType = "system"
	}

	if template {
		flagsSet++
		showType = "template"
	}

	if flagsSet > 1 {
		return errors.New("only one of '--license', '--modelfile', '--parameters', '--system', or '--template' can be specified")
	}

	req := api.ShowRequest{Name: args[0], Verbose: verbose}
	resp, err := client.Show(cmd.Context(), &req)
	if err != nil {
		return err
	}

	if slices.Contains(resp.Capabilities, model.CapabilityImage) {
		return errors.New("image generation models are not currently supported")
	}

	if flagsSet == 1 {
		switch showType {
		case "license":
			fmt.Println(resp.License)
		case "modelfile":
			fmt.Println(resp.Modelfile)
		case "parameters":
			fmt.Println(resp.Parameters)
		case "system":
			fmt.Print(resp.System)
		case "template":
			fmt.Print(resp.Template)
		}

		return nil
	}

	return showInfo(resp, verbose, os.Stdout)
}

func showInfo(resp *api.ShowResponse, verbose bool, w io.Writer) error {
	tableRender := func(header string, rows func() [][]string) {
		fmt.Fprintln(w, " ", header)
		table := tablewriter.NewWriter(w)
		table.SetAlignment(tablewriter.ALIGN_LEFT)
		table.SetBorder(false)
		table.SetNoWhiteSpace(true)
		table.SetTablePadding("    ")

		switch header {
		case "Template", "System", "License":
			table.SetColWidth(100)
		}

		table.AppendBulk(rows())
		table.Render()
		fmt.Fprintln(w)
	}

	tableRender("Model", func() (rows [][]string) {
		if resp.RemoteHost != "" {
			rows = append(rows, []string{"", "Remote model", resp.RemoteModel})
			rows = append(rows, []string{"", "Remote URL", resp.RemoteHost})
		}

		if resp.ModelInfo != nil {
			arch, _ := resp.ModelInfo["general.architecture"].(string)
			if arch != "" {
				rows = append(rows, []string{"", "architecture", arch})
			}

			var paramStr string
			if resp.Details.ParameterSize != "" {
				paramStr = resp.Details.ParameterSize
			} else if v, ok := resp.ModelInfo["general.parameter_count"]; ok {
				if f, ok := v.(float64); ok {
					paramStr = format.HumanNumber(uint64(f))
				}
			}
			if paramStr != "" {
				rows = append(rows, []string{"", "parameters", paramStr})
			}

			if v, ok := resp.ModelInfo[fmt.Sprintf("%s.context_length", arch)]; ok {
				if f, ok := v.(float64); ok {
					rows = append(rows, []string{"", "context length", strconv.FormatFloat(f, 'f', -1, 64)})
				}
			}

			if v, ok := resp.ModelInfo[fmt.Sprintf("%s.embedding_length", arch)]; ok {
				if f, ok := v.(float64); ok {
					rows = append(rows, []string{"", "embedding length", strconv.FormatFloat(f, 'f', -1, 64)})
				}
			}
		} else {
			rows = append(rows, []string{"", "architecture", resp.Details.Family})
			rows = append(rows, []string{"", "parameters", resp.Details.ParameterSize})
		}
		rows = append(rows, []string{"", "quantization", resp.Details.QuantizationLevel})
		if resp.Requires != "" {
			rows = append(rows, []string{"", "requires", resp.Requires})
		}
		if resp.Renderer != "" {
			rows = append(rows, []string{"", "renderer", resp.Renderer})
		}
		if resp.Parser != "" {
			rows = append(rows, []string{"", "parser", resp.Parser})
		}
		if resp.TemplateSource != "" && resp.TemplateSource != "none" {
			rows = append(rows, []string{"", "template source", resp.TemplateSource})
		}
		if len(resp.Manifests) > 0 {
			if runner, ok := showSelectedRunner(resp.Manifests); ok {
				rows = append(rows, []string{"", "runner", runner})
			}
			if runners := showAvailableRunners(resp.Manifests); runners != "" {
				rows = append(rows, []string{"", "available runners", runners})
			}
		}
		return
	})

	if len(resp.Capabilities) > 0 {
		tableRender("Capabilities", func() (rows [][]string) {
			for _, capability := range resp.Capabilities {
				rows = append(rows, []string{"", capability.String()})
				if capability == model.CapabilityThinking && resp.Thinking.Valid() {
					values := make([]string, len(resp.Thinking.Values))
					for i, value := range resp.Thinking.Values {
						values[i] = fmt.Sprint(value)
					}
					rows = append(rows,
						[]string{"", "    levels", strings.Join(values, ", ")},
						[]string{"", "    default", fmt.Sprint(resp.Thinking.Default)},
					)
				}
			}
			return
		})
	}

	if len(resp.Voices) > 0 {
		tableRender("Voices", func() (rows [][]string) {
			for _, voice := range resp.Voices {
				rows = append(rows, []string{"", voice})
			}
			return
		})
	}

	if resp.ProjectorInfo != nil {
		tableRender("Projector", func() (rows [][]string) {
			arch, _ := resp.ProjectorInfo["general.architecture"].(string)
			if arch != "" {
				rows = append(rows, []string{"", "architecture", arch})
			}
			if v, ok := resp.ProjectorInfo["general.parameter_count"].(float64); ok {
				rows = append(rows, []string{"", "parameters", format.HumanNumber(uint64(v))})
			}

			projectorValue := func(suffix string) (float64, bool) {
				for _, modality := range []string{"vision", "audio"} {
					if v, ok := resp.ProjectorInfo[fmt.Sprintf("%s.%s.%s", arch, modality, suffix)].(float64); ok {
						return v, true
					}
				}
				return 0, false
			}
			if v, ok := projectorValue("embedding_length"); ok {
				rows = append(rows, []string{"", "embedding length", strconv.FormatFloat(v, 'f', -1, 64)})
			}
			if v, ok := projectorValue("projection_dim"); ok {
				rows = append(rows, []string{"", "dimensions", strconv.FormatFloat(v, 'f', -1, 64)})
			}
			return
		})
	}

	if resp.Parameters != "" {
		tableRender("Parameters", func() (rows [][]string) {
			scanner := bufio.NewScanner(strings.NewReader(resp.Parameters))
			for scanner.Scan() {
				if text := scanner.Text(); text != "" {
					rows = append(rows, append([]string{""}, strings.Fields(text)...))
				}
			}
			return
		})
	}

	if resp.ModelInfo != nil && verbose {
		tableRender("Metadata", func() (rows [][]string) {
			keys := make([]string, 0, len(resp.ModelInfo))
			for k := range resp.ModelInfo {
				keys = append(keys, k)
			}
			sort.Strings(keys)

			for _, k := range keys {
				var v string
				switch vData := resp.ModelInfo[k].(type) {
				case bool:
					v = fmt.Sprintf("%t", vData)
				case string:
					v = vData
				case float64:
					v = fmt.Sprintf("%g", vData)
				case []any:
					targetWidth := 10 // Small width where we are displaying the data in a column

					var itemsToShow int
					totalWidth := 1 // Start with 1 for opening bracket

					// Find how many we can fit
					for i := range vData {
						itemStr := fmt.Sprintf("%v", vData[i])
						width := runewidth.StringWidth(itemStr)

						// Add separator width (", ") for all items except the first
						if i > 0 {
							width += 2
						}

						// Check if adding this item would exceed our width limit
						if totalWidth+width > targetWidth && i > 0 {
							break
						}

						totalWidth += width
						itemsToShow++
					}

					// Format the output
					if itemsToShow < len(vData) {
						v = fmt.Sprintf("%v", vData[:itemsToShow])
						v = strings.TrimSuffix(v, "]")
						v += fmt.Sprintf(" ...+%d more]", len(vData)-itemsToShow)
					} else {
						v = fmt.Sprintf("%v", vData)
					}
				default:
					v = fmt.Sprintf("%T", vData)
				}
				rows = append(rows, []string{"", k, v})
			}
			return
		})
	}

	if len(resp.Tensors) > 0 && verbose {
		tableRender("Tensors", func() (rows [][]string) {
			for _, t := range resp.Tensors {
				rows = append(rows, []string{"", t.Name, t.Type, fmt.Sprint(t.Shape)})
			}
			return
		})
	}

	head := func(s string, n int) (rows [][]string) {
		scanner := bufio.NewScanner(strings.NewReader(s))
		count := 0
		for scanner.Scan() {
			text := strings.TrimSpace(scanner.Text())
			if text == "" {
				continue
			}
			count++
			if n < 0 || count <= n {
				rows = append(rows, []string{"", text})
			}
		}
		if n >= 0 && count > n {
			rows = append(rows, []string{"", "..."})
		}
		return
	}

	if resp.System != "" {
		tableRender("System", func() [][]string {
			return head(resp.System, 2)
		})
	}

	if resp.License != "" {
		tableRender("License", func() [][]string {
			return head(resp.License, 2)
		})
	}

	return nil
}

func showSelectedRunner(manifests []api.ManifestSummary) (string, bool) {
	for _, m := range manifests {
		if m.Selected {
			return showRunnerName(m), true
		}
	}
	if len(manifests) == 1 {
		return showRunnerName(manifests[0]), true
	}
	return "", false
}

func showAvailableRunners(manifests []api.ManifestSummary) string {
	parts := make([]string, 0, len(manifests))
	for _, m := range manifests {
		if m.Selected {
			parts = append(parts, showRunnerSummary(m))
		}
	}
	for _, m := range manifests {
		if m.Selected {
			continue
		}
		parts = append(parts, showRunnerSummary(m))
	}
	return strings.Join(parts, ", ")
}

func showRunnerName(m api.ManifestSummary) string {
	if m.Runner != "" {
		return m.Runner
	}
	return "runner"
}

func showRunnerSummary(m api.ManifestSummary) string {
	label := showRunnerName(m)
	digest := showDigestSummary(m.Digest)
	if digest != "" {
		label += ":" + digest
	}
	return label
}

func showDigestSummary(digest string) string {
	digest = strings.ToLower(strings.Replace(digest, "-", ":", 1))
	algo, value, ok := strings.Cut(digest, ":")
	if !ok || algo == "" || value == "" {
		return ""
	}
	if len(value) > 12 {
		value = value[:12]
	}
	return algo + ":" + value
}

func CopyHandler(cmd *cobra.Command, args []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	req := api.CopyRequest{Source: args[0], Destination: args[1]}
	resp, err := client.Copy(cmd.Context(), &req)
	if err != nil {
		return err
	}
	fmt.Printf("copied '%s' to '%s'\n", args[0], args[1])
	fmt.Fprintln(os.Stderr, resp.Status)
	return nil
}

func PullHandler(cmd *cobra.Command, args []string) error {
	insecure, err := cmd.Flags().GetBool("insecure")
	if err != nil {
		return err
	}
	runner := ""
	if flag := cmd.Flags().Lookup("runner"); flag != nil {
		runner, err = cmd.Flags().GetString("runner")
		if err != nil {
			return err
		}
	}

	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	_, err = pullWithCloudSuggestion(cmd.Context(), client, args[0], runner, insecure, "pull")
	return err
}

// pullModelWithProgress pulls name, rendering progress to stderr. When
// clearNotFound is set and the pull fails because the model doesn't exist,
// the progress display is erased rather than left behind; callers set it
// when a ":cloud" suggestion prompt may immediately follow the failure.
func pullModelWithProgress(ctx context.Context, client *api.Client, name, runner string, insecure, clearNotFound bool) error {
	p := progress.NewProgress(os.Stderr)
	defer p.Stop()

	bars := make(map[string]*progress.Bar)

	var status string
	var spinner *progress.Spinner

	fn := func(resp api.ProgressResponse) error {
		if resp.Digest != "" {
			if resp.Completed == 0 {
				// This is the initial status update for the
				// layer, which the server sends before
				// beginning the download, for clients to
				// compute total size and prepare for
				// downloads, if needed.
				//
				// Skipping this here to avoid showing a 0%
				// progress bar, which *should* clue the user
				// into the fact that many things are being
				// downloaded and that the current active
				// download is not that last. However, in rare
				// cases it seems to be triggering to some, and
				// it isn't worth explaining, so just ignore
				// and regress to the old UI that keeps giving
				// you the "But wait, there is more!" after
				// each "100% done" bar, which is "better."
				return nil
			}

			if spinner != nil {
				spinner.Stop()
			}

			bar, ok := bars[resp.Digest]
			if !ok {
				name, isDigest := strings.CutPrefix(resp.Digest, "sha256:")
				name = strings.TrimSpace(name)
				if isDigest {
					name = name[:min(12, len(name))]
				}
				bar = progress.NewBar(fmt.Sprintf("pulling %s:", name), resp.Total, resp.Completed)
				bars[resp.Digest] = bar
				p.Add(resp.Digest, bar)
			}

			bar.Set(resp.Completed)
		} else if status != resp.Status {
			if spinner != nil {
				spinner.Stop()
			}

			status = resp.Status
			spinner = progress.NewSpinner(status)
			p.Add(status, spinner)
		}

		return nil
	}

	request := api.PullRequest{Name: name, Runner: runner, Insecure: insecure}
	err := client.Pull(ctx, &request, fn)
	if clearNotFound && isPullNotFoundErr(err) {
		// The deferred Stop becomes a no-op after this.
		p.StopAndClear()
	}
	return err
}

type generateContextKey string

type runOptions struct {
	Model          string
	Runner         string
	ParentModel    string
	LoadedMessages []api.Message
	Prompt         string
	Messages       []api.Message
	WordWrap       bool
	Format         string
	System         string
	Images         []api.ImageData
	Options        map[string]any
	MultiModal     bool
	KeepAlive      *api.Duration
	Think          *api.ThinkValue
	HideThinking   bool
	ShowConnect    bool
	Decision       bool
	Questions      *api.SystemOneQuestions
}

func (r runOptions) Copy() runOptions {
	var loadedMessages []api.Message
	if r.LoadedMessages != nil {
		loadedMessages = make([]api.Message, len(r.LoadedMessages))
		copy(loadedMessages, r.LoadedMessages)
	}

	var messages []api.Message
	if r.Messages != nil {
		messages = make([]api.Message, len(r.Messages))
		copy(messages, r.Messages)
	}

	var images []api.ImageData
	if r.Images != nil {
		images = make([]api.ImageData, len(r.Images))
		copy(images, r.Images)
	}

	var opts map[string]any
	if r.Options != nil {
		opts = make(map[string]any, len(r.Options))
		for k, v := range r.Options {
			opts[k] = v
		}
	}

	var think *api.ThinkValue
	if r.Think != nil {
		cThink := *r.Think
		think = &cThink
	}

	return runOptions{
		Model:          r.Model,
		Runner:         r.Runner,
		ParentModel:    r.ParentModel,
		LoadedMessages: loadedMessages,
		Prompt:         r.Prompt,
		Messages:       messages,
		WordWrap:       r.WordWrap,
		Format:         r.Format,
		System:         r.System,
		Images:         images,
		Options:        opts,
		MultiModal:     r.MultiModal,
		KeepAlive:      r.KeepAlive,
		Think:          think,
		HideThinking:   r.HideThinking,
		ShowConnect:    r.ShowConnect,
		Decision:       r.Decision,
		Questions:      r.Questions,
	}
}

func applyShowResponseToRunOptions(opts *runOptions, info *api.ShowResponse) {
	opts.ParentModel = info.Details.ParentModel
	opts.LoadedMessages = slices.Clone(info.Messages)
	opts.MultiModal = slices.Contains(info.Capabilities, model.CapabilityVision) ||
		slices.Contains(info.Capabilities, model.CapabilityAudio)

	// Keep media input working with older servers that do not report capabilities.
	if len(info.ProjectorInfo) != 0 {
		opts.MultiModal = true
	}
	for key := range info.ModelInfo {
		if strings.Contains(key, ".vision.") {
			opts.MultiModal = true
			break
		}
	}
}

type displayResponseState struct {
	lineLength int
	wordBuffer string
}

func displayResponse(content string, wordWrap bool, state *displayResponseState) {
	termWidth, _, _ := term.GetSize(int(os.Stdout.Fd()))
	if termWidth == 0 {
		termWidth = 80
	}
	if wordWrap && termWidth >= 10 {
		for _, ch := range content {
			if state.lineLength+1 > termWidth-5 {
				if runewidth.StringWidth(state.wordBuffer) > termWidth-10 {
					fmt.Printf("%s%c", state.wordBuffer, ch)
					state.wordBuffer = ""
					state.lineLength = 0
					continue
				}

				// backtrack the length of the last word and clear to the end of the line
				a := runewidth.StringWidth(state.wordBuffer)
				if a > 0 {
					fmt.Printf("\x1b[%dD", a)
				}
				fmt.Printf("\x1b[K\n")
				fmt.Printf("%s%c", state.wordBuffer, ch)
				chWidth := runewidth.RuneWidth(ch)

				state.lineLength = runewidth.StringWidth(state.wordBuffer) + chWidth
			} else {
				fmt.Print(string(ch))
				state.lineLength += runewidth.RuneWidth(ch)
				if runewidth.RuneWidth(ch) >= 2 {
					state.wordBuffer = ""
					continue
				}

				switch ch {
				case ' ', '\t':
					state.wordBuffer = ""
				case '\n', '\r':
					state.lineLength = 0
					state.wordBuffer = ""
				default:
					state.wordBuffer += string(ch)
				}
			}
		}
	} else {
		fmt.Printf("%s%s", state.wordBuffer, content)
		if len(state.wordBuffer) > 0 {
			state.wordBuffer = ""
		}
	}
}

func thinkingOutputOpeningText(plainText bool) string {
	text := "Thinking...\n"

	if plainText {
		return text
	}

	return readline.ColorGrey + readline.ColorBold + text + readline.ColorDefault + readline.ColorGrey
}

func thinkingOutputClosingText(plainText bool) string {
	text := "...done thinking.\n\n"

	if plainText {
		return text
	}

	return readline.ColorGrey + readline.ColorBold + text + readline.ColorDefault
}

func chat(cmd *cobra.Command, opts runOptions) (*api.Message, error) {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return nil, err
	}

	p := progress.NewProgress(os.Stderr)
	defer p.StopAndClear()

	spinner := progress.NewSpinner("")
	p.Add("", spinner)

	cancelCtx, cancel := context.WithCancel(cmd.Context())
	defer cancel()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT)

	go func() {
		<-sigChan
		cancel()
	}()

	var state *displayResponseState = &displayResponseState{}
	var thinkingContent strings.Builder
	var latest api.ChatResponse
	var fullResponse strings.Builder
	var thinkTagOpened bool = false
	var thinkTagClosed bool = false

	role := "assistant"

	fn := func(response api.ChatResponse) error {
		if response.Message.Content != "" || !opts.HideThinking {
			p.StopAndClear()
		}

		latest = response

		role = response.Message.Role
		if response.Message.Thinking != "" && !opts.HideThinking {
			if !thinkTagOpened {
				fmt.Print(thinkingOutputOpeningText(false))
				thinkTagOpened = true
				thinkTagClosed = false
			}
			thinkingContent.WriteString(response.Message.Thinking)
			displayResponse(response.Message.Thinking, opts.WordWrap, state)
		}

		content := response.Message.Content
		if thinkTagOpened && !thinkTagClosed && (content != "" || len(response.Message.ToolCalls) > 0) {
			if !strings.HasSuffix(thinkingContent.String(), "\n") {
				fmt.Println()
			}
			fmt.Print(thinkingOutputClosingText(false))
			thinkTagOpened = false
			thinkTagClosed = true
			state = &displayResponseState{}
		}
		// purposefully not putting thinking blocks in the response, which would
		// only be needed if we later added tool calling to the cli (they get
		// filtered out anyway since current models don't expect them unless you're
		// about to finish some tool calls)
		fullResponse.WriteString(content)

		if response.Message.ToolCalls != nil {
			toolCalls := response.Message.ToolCalls
			if len(toolCalls) > 0 {
				fmt.Print(renderToolCalls(toolCalls, false))
			}
		}

		displayResponse(content, opts.WordWrap, state)

		return nil
	}

	if opts.Format == "json" {
		opts.Format = `"` + opts.Format + `"`
	}

	req := &api.ChatRequest{
		Model:    opts.Model,
		Runner:   opts.Runner,
		Messages: opts.Messages,
		Format:   json.RawMessage(opts.Format),
		Options:  opts.Options,
		Think:    opts.Think,
	}

	if opts.KeepAlive != nil {
		req.KeepAlive = opts.KeepAlive
	}

	if err := client.Chat(cancelCtx, req, fn); err != nil {
		if errors.Is(err, context.Canceled) {
			return nil, nil
		}

		// this error should ideally be wrapped properly by the client
		if strings.Contains(err.Error(), "upstream error") {
			p.StopAndClear()
			fmt.Println("An error occurred while processing your message. Please try again.")
			fmt.Println()
			return nil, nil
		}
		return nil, err
	}

	if len(opts.Messages) > 0 {
		fmt.Println()
		fmt.Println()
	}

	verbose, err := cmd.Flags().GetBool("verbose")
	if err != nil {
		return nil, err
	}

	if verbose {
		latest.Summary()
	}

	return &api.Message{Role: role, Thinking: thinkingContent.String(), Content: fullResponse.String()}, nil
}

func generate(cmd *cobra.Command, opts runOptions) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	p := progress.NewProgress(os.Stderr)
	defer p.StopAndClear()

	spinner := progress.NewSpinner("")
	p.Add("", spinner)

	var latest api.GenerateResponse

	generateContext, ok := cmd.Context().Value(generateContextKey("context")).([]int)
	if !ok {
		generateContext = []int{}
	}

	ctx, cancel := context.WithCancel(cmd.Context())
	defer cancel()

	sigChan := make(chan os.Signal, 1)
	signal.Notify(sigChan, syscall.SIGINT)

	go func() {
		<-sigChan
		cancel()
	}()

	var state *displayResponseState = &displayResponseState{}
	var thinkingContent strings.Builder
	var thinkTagOpened bool = false
	var thinkTagClosed bool = false

	plainText := !term.IsTerminal(int(os.Stdout.Fd()))

	fn := func(response api.GenerateResponse) error {
		latest = response
		content := response.Response

		if response.Response != "" || !opts.HideThinking {
			p.StopAndClear()
		}

		if response.Thinking != "" && !opts.HideThinking {
			if !thinkTagOpened {
				fmt.Print(thinkingOutputOpeningText(plainText))
				thinkTagOpened = true
				thinkTagClosed = false
			}
			thinkingContent.WriteString(response.Thinking)
			displayResponse(response.Thinking, opts.WordWrap, state)
		}

		if thinkTagOpened && !thinkTagClosed && (content != "" || len(response.ToolCalls) > 0) {
			if !strings.HasSuffix(thinkingContent.String(), "\n") {
				fmt.Println()
			}
			fmt.Print(thinkingOutputClosingText(plainText))
			thinkTagOpened = false
			thinkTagClosed = true
			state = &displayResponseState{}
		}

		displayResponse(content, opts.WordWrap, state)

		if response.ToolCalls != nil {
			toolCalls := response.ToolCalls
			if len(toolCalls) > 0 {
				fmt.Print(renderToolCalls(toolCalls, plainText))
			}
		}

		return nil
	}

	if opts.MultiModal {
		opts.Prompt, opts.Images, err = extractFileData(opts.Prompt)
		if err != nil {
			return err
		}
	}

	if opts.Format == "json" {
		opts.Format = `"` + opts.Format + `"`
	}

	request := api.GenerateRequest{
		Model:     opts.Model,
		Runner:    opts.Runner,
		Prompt:    opts.Prompt,
		Context:   generateContext,
		Images:    opts.Images,
		Format:    json.RawMessage(opts.Format),
		System:    opts.System,
		Options:   opts.Options,
		KeepAlive: opts.KeepAlive,
		Think:     opts.Think,
	}

	if err := client.Generate(ctx, &request, fn); err != nil {
		if errors.Is(err, context.Canceled) {
			return nil
		}
		return err
	}

	if opts.Prompt != "" {
		fmt.Println()
		fmt.Println()
	}

	if !latest.Done {
		return nil
	}

	verbose, err := cmd.Flags().GetBool("verbose")
	if err != nil {
		return err
	}

	if verbose {
		latest.Summary()
	}

	ctx = context.WithValue(cmd.Context(), generateContextKey("context"), latest.Context)
	cmd.SetContext(ctx)

	return nil
}

func RunServer(_ *cobra.Command, _ []string) error {
	if err := initializeKeypair(); err != nil {
		return err
	}

	ln, err := net.Listen("tcp", envconfig.Host().Host)
	if err != nil {
		return err
	}

	err = server.Serve(ln)
	if errors.Is(err, http.ErrServerClosed) {
		return nil
	}

	return err
}

func initializeKeypair() error {
	home, err := os.UserHomeDir()
	if err != nil {
		return err
	}

	privKeyPath := filepath.Join(home, ".ollama", "id_ed25519")
	pubKeyPath := filepath.Join(home, ".ollama", "id_ed25519.pub")

	_, err = os.Stat(privKeyPath)
	if os.IsNotExist(err) {
		fmt.Printf("Couldn't find '%s'. Generating new private key.\n", privKeyPath)
		cryptoPublicKey, cryptoPrivateKey, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			return err
		}

		privateKeyBytes, err := ssh.MarshalPrivateKey(cryptoPrivateKey, "")
		if err != nil {
			return err
		}

		if err := os.MkdirAll(filepath.Dir(privKeyPath), 0o755); err != nil {
			return fmt.Errorf("could not create directory %w", err)
		}

		if err := os.WriteFile(privKeyPath, pem.EncodeToMemory(privateKeyBytes), 0o600); err != nil {
			return err
		}

		sshPublicKey, err := ssh.NewPublicKey(cryptoPublicKey)
		if err != nil {
			return err
		}

		publicKeyBytes := ssh.MarshalAuthorizedKey(sshPublicKey)

		if err := os.WriteFile(pubKeyPath, publicKeyBytes, 0o644); err != nil {
			return err
		}

		fmt.Printf("Your new public key is: \n\n%s\n", publicKeyBytes)
	}
	return nil
}

func checkServerHeartbeat(cmd *cobra.Command, _ []string) error {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}
	if err := client.Heartbeat(cmd.Context()); err != nil {
		if !(strings.Contains(err.Error(), " refused") || strings.Contains(err.Error(), "could not connect")) {
			return err
		}
		if err := startApp(cmd.Context(), client); err != nil { //nolint:staticcheck,nolintlint // startApp always returns non-nil on Linux (start_default.go) but can return nil on macOS/Windows
			return err
		}
	}
	return nil
}

func versionHandler(cmd *cobra.Command, _ []string) {
	client, err := api.ClientFromEnvironment()
	if err != nil {
		return
	}

	serverVersion, err := client.Version(cmd.Context())
	if err != nil {
		fmt.Println("Warning: could not connect to a running Ollama instance")
	}

	if serverVersion != "" {
		fmt.Printf("ollama version is %s\n", serverVersion)
	}

	if serverVersion != version.Version {
		fmt.Printf("Warning: client version is %s\n", version.Version)
	}
}

func appendEnvDocs(cmd *cobra.Command, envs []envconfig.EnvVar) {
	if len(envs) == 0 {
		return
	}

	envUsage := `
Environment Variables:
`
	for _, e := range envs {
		envUsage += fmt.Sprintf("      %-27s   %s\n", e.Name, e.Description)
	}

	cmd.SetUsageTemplate(cmd.UsageTemplate() + envUsage)
}

func launchInteractiveModel(cmd *cobra.Command, modelName string) error {
	opts := runOptions{
		Model:       modelName,
		WordWrap:    os.Getenv("TERM") == "xterm-256color",
		Options:     map[string]any{},
		ShowConnect: true,
	}

	client, err := api.ClientFromEnvironment()
	if err != nil {
		return err
	}

	info, resolvedModel, err := showOrPullModel(cmd, client, modelName, "", false, "run")
	if err != nil {
		if handleCloudAuthorizationError(err) {
			return nil
		}
		return err
	}
	opts.Model = resolvedModel
	ensureCloudStub(cmd.Context(), client, opts.Model)

	opts.Think, err = inferThinkingOption(&info.Capabilities, &opts, false)
	if err != nil {
		return err
	}

	applyShowResponseToRunOptions(&opts, info)

	if err := loadOrUnloadModel(cmd, &opts); err != nil {
		return fmt.Errorf("error loading model: %w", err)
	}
	if err := generateInteractive(cmd, opts); err != nil {
		return fmt.Errorf("error running model: %w", err)
	}
	return nil
}

// runInteractiveTUI runs the main interactive TUI menu.
func runInteractiveTUI(cmd *cobra.Command) {
	// Ensure the server is running via the shared checkServerHeartbeat path.
	if err := checkServerHeartbeat(cmd, nil); err != nil {
		fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		return
	}

	accountPrefetch := launch.StartAccountStatePrefetch(cmd.Context())
	deps := launcherDeps{
		buildState:          launch.BuildLauncherState,
		runMenu:             tui.RunMenu,
		resolveRunModel:     launch.ResolveRunModel,
		launchIntegration:   launch.LaunchIntegration,
		runModel:            launchInteractiveModel,
		accountState:        accountPrefetch.StateIfReady,
		accountStateUpdates: accountPrefetch.StateUpdates,
	}

	for {
		continueLoop, err := runInteractiveTUIStep(cmd, deps)
		if err != nil {
			fmt.Fprintf(os.Stderr, "Error: %v\n", err)
		}
		if !continueLoop {
			return
		}
	}
}

type launcherDeps struct {
	buildState          func(context.Context) (*launch.LauncherState, error)
	runMenu             func(*launch.LauncherState) (tui.TUIAction, error)
	resolveRunModel     func(context.Context, launch.RunModelRequest) (string, error)
	launchIntegration   func(context.Context, launch.IntegrationLaunchRequest) error
	runModel            func(*cobra.Command, string) error
	accountState        func() *launch.AccountState
	accountStateUpdates func(context.Context) <-chan *launch.AccountState
}

func runInteractiveTUIStep(cmd *cobra.Command, deps launcherDeps) (bool, error) {
	state, err := deps.buildState(cmd.Context())
	if err != nil {
		return false, fmt.Errorf("build launcher state: %w", err)
	}
	if state != nil && deps.accountState != nil {
		state.AccountState = deps.accountState()
	}

	action, err := deps.runMenu(state)
	if err != nil {
		return false, fmt.Errorf("run launcher menu: %w", err)
	}

	return runLauncherAction(cmd, action, deps)
}

func saveLauncherSelection(action tui.TUIAction) {
	// Best effort only: this affects menu recall, not launch correctness.
	_ = config.SetLastSelection(action.LastSelection())
}

func runLauncherAction(cmd *cobra.Command, action tui.TUIAction, deps launcherDeps) (bool, error) {
	switch action.Kind {
	case tui.TUIActionNone:
		return false, nil
	case tui.TUIActionRunModel:
		saveLauncherSelection(action)
		req := action.RunModelRequest()
		if deps.accountState != nil {
			req.AccountState = deps.accountState()
			req.AccountStateProvider = deps.accountState
		}
		req.AccountStateUpdates = deps.accountStateUpdates
		modelName, err := deps.resolveRunModel(cmd.Context(), req)
		if errors.Is(err, launch.ErrCancelled) {
			return true, nil
		}
		if err != nil {
			return true, fmt.Errorf("selecting model: %w", err)
		}
		if err := deps.runModel(cmd, modelName); err != nil {
			return true, err
		}
		return true, nil
	case tui.TUIActionLaunchIntegration:
		saveLauncherSelection(action)
		req := action.IntegrationLaunchRequest()
		if deps.accountState != nil {
			req.AccountState = deps.accountState()
			req.AccountStateProvider = deps.accountState
		}
		req.AccountStateUpdates = deps.accountStateUpdates
		err := deps.launchIntegration(cmd.Context(), req)
		if errors.Is(err, launch.ErrCancelled) {
			return true, nil
		}
		if err != nil {
			return true, fmt.Errorf("launching %s: %w", action.Integration, err)
		}
		if launcherActionExitsLoop(action.Integration) {
			return false, nil
		}
		return true, nil
	default:
		return false, fmt.Errorf("unknown launcher action: %d", action.Kind)
	}
}

func launcherActionExitsLoop(integration string) bool {
	switch integration {
	case "chatgpt", "codex-app", "vscode":
		return true
	default:
		return false
	}
}

func NewCLI() *cobra.Command {
	log.SetFlags(log.LstdFlags | log.Lshortfile)
	cobra.EnableCommandSorting = false

	if runtime.GOOS == "windows" && term.IsTerminal(int(os.Stdout.Fd())) {
		console.ConsoleFromFile(os.Stdin) //nolint:errcheck
	}

	rootCmd := &cobra.Command{
		Use:           "ollama",
		Short:         "Large language model runner",
		SilenceUsage:  true,
		SilenceErrors: true,
		CompletionOptions: cobra.CompletionOptions{
			DisableDefaultCmd: true,
		},
		Run: func(cmd *cobra.Command, args []string) {
			if version, _ := cmd.Flags().GetBool("version"); version {
				versionHandler(cmd, args)
				return
			}

			if err := runWelcome(); err != nil {
				if !errors.Is(err, launch.ErrCancelled) {
					fmt.Fprintf(os.Stderr, "Error: %v\n", err)
				}
				return
			}
			runInteractiveTUI(cmd)
		},
	}

	rootCmd.Flags().BoolP("version", "v", false, "Show version information")
	rootCmd.Flags().Bool("verbose", false, "Show timings for response")
	rootCmd.Flags().Bool("nowordwrap", false, "Don't wrap words to the next line automatically")

	createCmd := &cobra.Command{
		Use:   "create MODEL",
		Short: "Create a model",
		Args:  cobra.ExactArgs(1),
		RunE:  CreateHandler,
	}

	createCmd.Flags().StringP("file", "f", "", "Name of the Modelfile (default \"Modelfile\")")
	createCmd.Flags().StringP("quantize", "q", "", "Quantize safetensors model to this level (e.g. nvfp4)")
	createCmd.Flags().StringSlice("combine", nil, "Create a manifest list from comma-separated local models")
	createCmd.Flags().String("draft-quantize", "", "Quantize safetensors draft model to this level")
	createCmd.Flags().Bool("force", false, "Continue local creation when MLX validation fails")
	createCmd.Flags().Bool("experimental", false, "Deprecated no-op")
	createCmd.Flags().MarkHidden("experimental")

	showCmd := &cobra.Command{
		Use:     "show MODEL",
		Short:   "Show information for a model",
		Args:    cobra.ExactArgs(1),
		PreRunE: checkServerHeartbeat,
		RunE:    ShowHandler,
	}

	showCmd.Flags().Bool("license", false, "Show license of a model")
	showCmd.Flags().Bool("modelfile", false, "Show Modelfile of a model")
	showCmd.Flags().Bool("parameters", false, "Show parameters of a model")
	showCmd.Flags().Bool("template", false, "Show template of a model")
	showCmd.Flags().Bool("system", false, "Show system message of a model")
	showCmd.Flags().BoolP("verbose", "v", false, "Show detailed model information")

	runCmd := &cobra.Command{
		Use:   "run MODEL [PROMPT]",
		Short: "Run a model",
		Example: `  ollama run gemma4
  ollama run gemma4 "Why is the sky blue?"
  ollama run nimble --ask "Is a refund being requested?" < ticket.txt
  ollama run nimble --ask "Which team should handle this?" \
    --choice billing="Payments and refunds" \
    --choice technical="Software problems" < ticket.txt
  ollama run nimble --ask "How urgent is this?" \
    --level "Routine" \
    --level "Soon" \
    --level "Immediate" < ticket.txt`,
		Args:    cobra.MinimumNArgs(1),
		PreRunE: checkServerHeartbeat,
		RunE:    RunHandler,
	}

	runCmd.Flags().String("keepalive", "", "Duration to keep a model loaded (e.g. 5m)")
	runCmd.Flags().Bool("verbose", false, "Show timings for response")
	runCmd.Flags().Bool("insecure", false, "Use an insecure registry")
	runCmd.Flags().Bool("nowordwrap", false, "Don't wrap words to the next line automatically")
	runCmd.Flags().String("format", "", "Response format (e.g. json)")
	runCmd.Flags().String("runner", "", "Runner to use for manifest list selection (mlx, ggml, llamacpp)")
	runCmd.Flags().MarkHidden("runner")
	runCmd.Flags().String("think", "", "Enable thinking mode: true/false or high/medium/low for supported models")
	runCmd.Flags().Lookup("think").NoOptDefVal = "true"
	runCmd.Flags().Bool("hidethinking", false, "Hide thinking output (if provided)")
	runCmd.Flags().Bool("truncate", false, "For embedding models: truncate inputs exceeding context length (default: true). Set --truncate=false to error instead")
	runCmd.Flags().Int("dimensions", 0, "Truncate output embeddings to specified dimension (embedding models only)")
	runCmd.Flags().String("voice", "", "Voice to speak with (speech models only)")
	var asked []askedQuestion
	runCmd.Flags().Var(questionFlag{"ask", &asked}, "ask", "Ask a decision model a question, answered yes or no unless --choice or --level follow")
	runCmd.Flags().Var(questionFlag{"choice", &asked}, "choice", `Add a label for the preceding --ask to choose from, e.g. billing="Payments and refunds"`)
	runCmd.Flags().Var(questionFlag{"level", &asked}, "level", "Add a level to score the preceding --ask on, from lowest to highest")

	stopCmd := &cobra.Command{
		Use:     "stop MODEL",
		Short:   "Stop a running model",
		Args:    cobra.ExactArgs(1),
		PreRunE: checkServerHeartbeat,
		RunE:    StopHandler,
	}

	serveCmd := &cobra.Command{
		Use:     "serve",
		Aliases: []string{"start"},
		Short:   "Start Ollama",
		Args:    cobra.ExactArgs(0),
		RunE:    RunServer,
	}

	pullCmd := &cobra.Command{
		Use:     "pull MODEL",
		Short:   "Pull a model from a registry",
		Args:    cobra.ExactArgs(1),
		PreRunE: checkServerHeartbeat,
		RunE:    PullHandler,
	}

	pullCmd.Flags().Bool("insecure", false, "Use an insecure registry")
	pullCmd.Flags().String("runner", "", "Runner to use for manifest list selection (mlx, ggml, llamacpp)")
	pullCmd.Flags().MarkHidden("runner")

	pushCmd := &cobra.Command{
		Use:     "push MODEL",
		Short:   "Push a model to a registry",
		Args:    cobra.ExactArgs(1),
		PreRunE: checkServerHeartbeat,
		RunE:    PushHandler,
	}

	pushCmd.Flags().Bool("insecure", false, "Use an insecure registry")

	signinCmd := &cobra.Command{
		Use:     "signin",
		Short:   "Sign in to ollama.com",
		Args:    cobra.ExactArgs(0),
		PreRunE: checkServerHeartbeat,
		RunE:    SigninHandler,
	}

	loginCmd := &cobra.Command{
		Use:     "login",
		Short:   "Sign in to ollama.com",
		Hidden:  true,
		Args:    cobra.ExactArgs(0),
		PreRunE: checkServerHeartbeat,
		RunE:    SigninHandler,
	}

	signoutCmd := &cobra.Command{
		Use:     "signout",
		Short:   "Sign out from ollama.com",
		Args:    cobra.ExactArgs(0),
		PreRunE: checkServerHeartbeat,
		RunE:    SignoutHandler,
	}

	logoutCmd := &cobra.Command{
		Use:     "logout",
		Short:   "Sign out from ollama.com",
		Hidden:  true,
		Args:    cobra.ExactArgs(0),
		PreRunE: checkServerHeartbeat,
		RunE:    SignoutHandler,
	}

	listCmd := &cobra.Command{
		Use:     "list",
		Aliases: []string{"ls"},
		Short:   "List models",
		PreRunE: checkServerHeartbeat,
		RunE:    ListHandler,
	}

	psCmd := &cobra.Command{
		Use:     "ps",
		Short:   "List running models",
		PreRunE: checkServerHeartbeat,
		RunE:    ListRunningHandler,
	}
	copyCmd := &cobra.Command{
		Use:     "cp SOURCE DESTINATION",
		Short:   "Copy a model",
		Args:    cobra.ExactArgs(2),
		PreRunE: checkServerHeartbeat,
		RunE:    CopyHandler,
	}

	deleteCmd := &cobra.Command{
		Use:     "rm MODEL [MODEL...]",
		Short:   "Remove a model",
		Args:    cobra.MinimumNArgs(1),
		PreRunE: checkServerHeartbeat,
		RunE:    DeleteHandler,
	}

	runnerCmd := &cobra.Command{
		Use:    "runner",
		Hidden: true,
		RunE: func(cmd *cobra.Command, args []string) error {
			return mlxrunner.Execute(os.Args[2:])
		},
		FParseErrWhitelist: cobra.FParseErrWhitelist{UnknownFlags: true},
	}
	runnerCmd.SetHelpFunc(func(cmd *cobra.Command, args []string) {
		_ = mlxrunner.Execute([]string{"--help"})
	})

	var gpuDiscoverLibDirs []string
	gpuDiscoverCmd := &cobra.Command{
		Use:    "gpu-discover",
		Hidden: true,
		RunE: func(cmd *cobra.Command, _ []string) error {
			return discover.RunNativeProbeCommand(cmd.Context(), gpuDiscoverLibDirs, os.Stdout)
		},
	}
	gpuDiscoverCmd.Flags().StringArrayVar(&gpuDiscoverLibDirs, "lib-dir", nil, "Ollama runtime library directory")

	envVars := envconfig.AsMap()

	envs := []envconfig.EnvVar{envVars["OLLAMA_HOST"]}

	for _, cmd := range []*cobra.Command{
		createCmd,
		showCmd,
		runCmd,
		stopCmd,
		pullCmd,
		pushCmd,
		listCmd,
		psCmd,
		copyCmd,
		deleteCmd,
		serveCmd,
	} {
		switch cmd {
		case runCmd:
			appendEnvDocs(cmd, []envconfig.EnvVar{envVars["OLLAMA_EDITOR"], envVars["OLLAMA_HOST"], envVars["OLLAMA_NOHISTORY"]})
		case serveCmd:
			appendEnvDocs(cmd, []envconfig.EnvVar{
				envVars["OLLAMA_DEBUG"],
				envVars["OLLAMA_HOST"],
				envVars["OLLAMA_CONTEXT_LENGTH"],
				envVars["OLLAMA_KEEP_ALIVE"],
				envVars["OLLAMA_MAX_LOADED_MODELS"],
				envVars["OLLAMA_MAX_TRANSFER_STREAMS"],
				envVars["OLLAMA_MAX_QUEUE"],
				envVars["OLLAMA_MODELS"],
				envVars["OLLAMA_NUM_PARALLEL"],
				envVars["OLLAMA_NO_CLOUD"],
				envVars["OLLAMA_NOPRUNE"],
				envVars["OLLAMA_ORIGINS"],
				envVars["OLLAMA_SCHED_SPREAD"],
				envVars["OLLAMA_FLASH_ATTENTION"],
				envVars["OLLAMA_KV_CACHE_TYPE"],
				envVars["OLLAMA_LLM_LIBRARY"],
				envVars["OLLAMA_GPU_OVERHEAD"],
				envVars["OLLAMA_IGPU_ENABLE"],
				envVars["LLAMA_ARG_FIT"],
				envVars["LLAMA_ARG_FIT_TARGET"],
				envVars["OLLAMA_LOAD_TIMEOUT"],
			})
		default:
			appendEnvDocs(cmd, envs)
		}
	}

	rootCmd.AddCommand(
		serveCmd,
		createCmd,
		showCmd,
		runCmd,
		stopCmd,
		pullCmd,
		pushCmd,
		signinCmd,
		loginCmd,
		signoutCmd,
		logoutCmd,
		listCmd,
		psCmd,
		copyCmd,
		deleteCmd,
		runnerCmd,
		gpuDiscoverCmd,
		launch.LaunchCmd(checkServerHeartbeat, runInteractiveTUI),
	)

	return rootCmd
}

// If the user has explicitly set thinking options, either through the CLI or
// through the `/set think` or `set nothink` interactive options, then we
// respect them. Otherwise, we check model capabilities to see if the model
// supports thinking. If the model does support thinking, we enable it.
// Otherwise, we unset the thinking option (which is different than setting it
// to false).
//
// If capabilities are not provided, we fetch them from the server.
func inferThinkingOption(caps *[]model.Capability, runOpts *runOptions, explicitlySetByUser bool) (*api.ThinkValue, error) {
	if explicitlySetByUser {
		return runOpts.Think, nil
	}

	if caps == nil {
		client, err := api.ClientFromEnvironment()
		if err != nil {
			return nil, err
		}
		ret, err := client.Show(context.Background(), &api.ShowRequest{
			Model: runOpts.Model,
		})
		if err != nil {
			return nil, err
		}
		caps = &ret.Capabilities
	}

	thinkingSupported := false
	for _, cap := range *caps {
		if cap == model.CapabilityThinking {
			thinkingSupported = true
		}
	}

	if thinkingSupported {
		return &api.ThinkValue{Value: true}, nil
	}

	return nil, nil
}

func renderToolCalls(toolCalls []api.ToolCall, plainText bool) string {
	out := ""
	formatExplanation := ""
	formatValues := ""
	if !plainText {
		formatExplanation = readline.ColorGrey + readline.ColorBold
		formatValues = readline.ColorDefault
		out += formatExplanation
	}
	for i, toolCall := range toolCalls {
		argsAsJSON, err := json.Marshal(toolCall.Function.Arguments)
		if err != nil {
			return ""
		}
		if i > 0 {
			out += "\n"
		}
		// all tool calls are unexpected since we don't currently support registering any in the CLI
		out += fmt.Sprintf("  Model called a non-existent function '%s()' with arguments: %s", formatValues+toolCall.Function.Name+formatExplanation, formatValues+string(argsAsJSON)+formatExplanation)
	}
	if !plainText {
		out += readline.ColorDefault
	}
	return out
}
