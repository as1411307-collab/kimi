package launch

import (
	"fmt"
	"os"
	"path/filepath"
	"runtime"
	"slices"
	"strings"
	"testing"

	"github.com/ollama/ollama/envconfig"
)

func TestClaudeIntegration(t *testing.T) {
	c := &Claude{}

	t.Run("String", func(t *testing.T) {
		if got := c.String(); got != "Claude Code" {
			t.Errorf("String() = %q, want %q", got, "Claude Code")
		}
	})

	t.Run("implements Runner", func(t *testing.T) {
		var _ Runner = c
	})
}

func TestClaudeFindPath(t *testing.T) {
	c := &Claude{}

	t.Run("finds claude in PATH", func(t *testing.T) {
		tmpDir := t.TempDir()
		name := "claude"
		if runtime.GOOS == "windows" {
			name = "claude.exe"
		}
		fakeBin := filepath.Join(tmpDir, name)
		os.WriteFile(fakeBin, []byte("#!/bin/sh\n"), 0o755)
		t.Setenv("PATH", tmpDir)

		got, err := c.findPath()
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		if got != fakeBin {
			t.Errorf("findPath() = %q, want %q", got, fakeBin)
		}
	})

	t.Run("falls back to ~/.claude/local/claude", func(t *testing.T) {
		tmpDir := t.TempDir()
		setTestHome(t, tmpDir)
		t.Setenv("PATH", t.TempDir()) // empty dir, no claude binary

		name := "claude"
		if runtime.GOOS == "windows" {
			name = "claude.exe"
		}
		fallback := filepath.Join(tmpDir, ".claude", "local", name)
		os.MkdirAll(filepath.Dir(fallback), 0o755)
		os.WriteFile(fallback, []byte("#!/bin/sh\n"), 0o755)

		got, err := c.findPath()
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		if got != fallback {
			t.Errorf("findPath() = %q, want %q", got, fallback)
		}
	})

	t.Run("falls back to ~/.local/bin/claude", func(t *testing.T) {
		tmpDir := t.TempDir()
		setTestHome(t, tmpDir)
		t.Setenv("PATH", t.TempDir()) // empty dir, no claude binary

		name := "claude"
		if runtime.GOOS == "windows" {
			name = "claude.exe"
		}
		fallback := filepath.Join(tmpDir, ".local", "bin", name)
		os.MkdirAll(filepath.Dir(fallback), 0o755)
		os.WriteFile(fallback, []byte("#!/bin/sh\n"), 0o755)

		got, err := c.findPath()
		if err != nil {
			t.Fatalf("unexpected error: %v", err)
		}
		if got != fallback {
			t.Errorf("findPath() = %q, want %q", got, fallback)
		}
	})

	t.Run("returns error when neither PATH nor fallback exists", func(t *testing.T) {
		tmpDir := t.TempDir()
		setTestHome(t, tmpDir)
		t.Setenv("PATH", t.TempDir()) // empty dir, no claude binary

		_, err := c.findPath()
		if err == nil {
			t.Fatal("expected error, got nil")
		}
	})
}

func TestEnsureClaudeInstalled(t *testing.T) {
	withConfirm := func(t *testing.T, fn func(prompt string) (bool, error)) {
		t.Helper()
		oldConfirm := DefaultConfirmPrompt
		DefaultConfirmPrompt = func(prompt string, options ConfirmOptions) (bool, error) {
			return fn(prompt)
		}
		t.Cleanup(func() { DefaultConfirmPrompt = oldConfirm })
	}

	t.Run("already installed", func(t *testing.T) {
		setTestHome(t, t.TempDir())
		tmpDir := t.TempDir()
		t.Setenv("PATH", tmpDir)
		writeFakeBinary(t, tmpDir, "claude")

		withConfirm(t, func(prompt string) (bool, error) {
			t.Fatalf("did not expect prompt, got %q", prompt)
			return false, nil
		})

		bin, err := ensureClaudeInstalled()
		if err != nil {
			t.Fatalf("ensureClaudeInstalled() error = %v", err)
		}
		if filepath.Base(bin) != "claude" && filepath.Base(bin) != "claude.cmd" {
			t.Fatalf("bin = %q, want claude binary", bin)
		}
	})

	t.Run("missing dependencies", func(t *testing.T) {
		setTestHome(t, t.TempDir())
		t.Setenv("PATH", t.TempDir())

		withConfirm(t, func(prompt string) (bool, error) {
			t.Fatalf("did not expect prompt, got %q", prompt)
			return false, nil
		})

		_, err := ensureClaudeInstalled()
		if err == nil || !strings.Contains(err.Error(), "required dependencies are missing") {
			t.Fatalf("expected missing dependency error, got %v", err)
		}
	})

	t.Run("missing and user declines install", func(t *testing.T) {
		setTestHome(t, t.TempDir())
		tmpDir := t.TempDir()
		t.Setenv("PATH", tmpDir)
		writeClaudeInstallerDeps(t, tmpDir)

		withConfirm(t, func(prompt string) (bool, error) {
			if prompt != "Claude Code is not installed. Install now?" {
				t.Fatalf("unexpected prompt: %q", prompt)
			}
			return false, nil
		})

		_, err := ensureClaudeInstalled()
		if err == nil || !strings.Contains(err.Error(), "installation cancelled") {
			t.Fatalf("expected cancellation error, got %v", err)
		}
	})

	t.Run("missing and user confirms install succeeds", func(t *testing.T) {
		if runtime.GOOS == "windows" {
			t.Skip("uses POSIX shell fake binaries")
		}

		homeDir := t.TempDir()
		setTestHome(t, homeDir)
		tmpDir := t.TempDir()
		t.Setenv("PATH", tmpDir)

		writeFakeBinary(t, tmpDir, "curl")

		installLog := filepath.Join(tmpDir, "bash.log")
		installedClaude := filepath.Join(homeDir, ".local", "bin", "claude")
		bashScript := fmt.Sprintf(`#!/bin/sh
echo "$@" >> %q
if [ "$1" = "-c" ]; then
  /bin/mkdir -p %q
  /bin/cat > %q <<'EOS'
#!/bin/sh
exit 0
EOS
  /bin/chmod +x %q
fi
exit 0
`, installLog, filepath.Dir(installedClaude), installedClaude, installedClaude)
		if err := os.WriteFile(filepath.Join(tmpDir, "bash"), []byte(bashScript), 0o755); err != nil {
			t.Fatalf("failed to write fake bash: %v", err)
		}

		withConfirm(t, func(prompt string) (bool, error) {
			return true, nil
		})

		bin, err := ensureClaudeInstalled()
		if err != nil {
			t.Fatalf("ensureClaudeInstalled() error = %v", err)
		}
		if bin != installedClaude {
			t.Fatalf("bin = %q, want %q", bin, installedClaude)
		}

		logData, err := os.ReadFile(installLog)
		if err != nil {
			t.Fatalf("failed to read install log: %v", err)
		}
		if !strings.Contains(string(logData), "https://claude.ai/install.sh") {
			t.Fatalf("expected install.sh command in log, got:\n%s", string(logData))
		}
	})

	t.Run("install command fails", func(t *testing.T) {
		if runtime.GOOS == "windows" {
			t.Skip("uses POSIX shell fake binaries")
		}

		setTestHome(t, t.TempDir())
		tmpDir := t.TempDir()
		t.Setenv("PATH", tmpDir)
		writeFakeBinary(t, tmpDir, "curl")
		if err := os.WriteFile(filepath.Join(tmpDir, "bash"), []byte("#!/bin/sh\nexit 1\n"), 0o755); err != nil {
			t.Fatalf("failed to write fake bash: %v", err)
		}

		withConfirm(t, func(prompt string) (bool, error) {
			return true, nil
		})

		_, err := ensureClaudeInstalled()
		if err == nil || !strings.Contains(err.Error(), "failed to install claude") {
			t.Fatalf("expected install failure error, got %v", err)
		}
	})
}

func writeClaudeInstallerDeps(t *testing.T, dir string) {
	t.Helper()
	if runtime.GOOS == "windows" {
		writeFakeBinary(t, dir, "powershell")
		return
	}
	writeFakeBinary(t, dir, "curl")
	writeFakeBinary(t, dir, "bash")
}

func TestClaudeInstallerCommand(t *testing.T) {
	tests := []struct {
		name    string
		goos    string
		wantBin string
		want    string
		wantErr string
	}{
		{
			name:    "unix",
			goos:    "linux",
			wantBin: "bash",
			want:    "curl -fsSL https://claude.ai/install.sh | bash",
		},
		{
			name:    "macos",
			goos:    "darwin",
			wantBin: "bash",
			want:    "curl -fsSL https://claude.ai/install.sh | bash",
		},
		{
			name:    "windows",
			goos:    "windows",
			wantBin: "powershell",
			want:    "irm https://claude.ai/install.ps1 | iex",
		},
		{
			name:    "unsupported",
			goos:    "plan9",
			wantErr: "unsupported platform",
		},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			bin, args, err := claudeInstallerCommand(tt.goos)
			if tt.wantErr != "" {
				if err == nil || !strings.Contains(err.Error(), tt.wantErr) {
					t.Fatalf("expected error containing %q, got %v", tt.wantErr, err)
				}
				return
			}
			if err != nil {
				t.Fatalf("claudeInstallerCommand() error = %v", err)
			}
			if bin != tt.wantBin {
				t.Fatalf("bin = %q, want %q", bin, tt.wantBin)
			}
			if !slices.Contains(args, tt.want) {
				t.Fatalf("args = %v, want command containing %q", args, tt.want)
			}
		})
	}
}

func TestClaudeArgs(t *testing.T) {
	c := &Claude{}

	tests := []struct {
		name  string
		model string
		args  []string
		want  []string
	}{
		{"with model", "llama3.2", nil, []string{"--model", "llama3.2"}},
		{"empty model", "", nil, nil},
		{"with model and verbose", "llama3.2", []string{"--verbose"}, []string{"--model", "llama3.2", "--verbose"}},
		{"empty model with help", "", []string{"--help"}, []string{"--help"}},
		{"with allowed tools", "llama3.2", []string{"--allowedTools", "Read,Write,Bash"}, []string{"--model", "llama3.2", "--allowedTools", "Read,Write,Bash"}},
		{"with channels", "llama3.2", []string{"--channels", "plugin:telegram@claude-plugins-official"}, []string{"--model", "llama3.2", "--channels", "plugin:telegram@claude-plugins-official"}},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := c.args(tt.model, tt.args)
			if !slices.Equal(got, tt.want) {
				t.Errorf("args(%q, %v) = %v, want %v", tt.model, tt.args, got, tt.want)
			}
		})
	}
}

func TestClaudeEnvVars(t *testing.T) {
	c := &Claude{}

	envMap := func(envs []string) map[string]string {
		m := make(map[string]string)
		for _, e := range envs {
			k, v, _ := strings.Cut(e, "=")
			m[k] = v
		}
		return m
	}

	got := envMap(c.envVars("llama3.2", nil))
	for key, want := range map[string]string{
		"ANTHROPIC_BASE_URL":                  envconfig.Host().String(),
		"ANTHROPIC_API_KEY":                   "",
		"ANTHROPIC_AUTH_TOKEN":                "ollama",
		"ENABLE_CLAUDEAI_MCP_SERVERS":         "false",
		"CLAUDE_CODE_ATTRIBUTION_HEADER":      "0",
		"CLAUDE_CODE_TOTAL_TOKENS_REMINDER":   "off",
		"DISABLE_ERROR_REPORTING":             "1",
		"DISABLE_FEEDBACK_COMMAND":            "1",
		"CLAUDE_CODE_DISABLE_FEEDBACK_SURVEY": "1",
		"ANTHROPIC_DEFAULT_OPUS_MODEL":        "llama3.2",
		"ANTHROPIC_DEFAULT_SONNET_MODEL":      "llama3.2",
		"ANTHROPIC_DEFAULT_HAIKU_MODEL":       "llama3.2",
		"CLAUDE_CODE_SUBAGENT_MODEL":          "llama3.2",
	} {
		if got[key] != want {
			t.Errorf("%s = %q, want %q", key, got[key], want)
		}
	}

	// Both variables disable Claude Code feature-flag evaluation, which keeps Channels unavailable.
	for _, key := range []string{"CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC", "DISABLE_TELEMETRY"} {
		if _, ok := got[key]; ok {
			t.Errorf("%s must not be set by Ollama", key)
		}
	}
}

func TestClaudeRunRoutesThroughOllama(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("uses a POSIX shell fake binary")
	}

	for _, model := range []string{"llama3.2", "kimi-k3:cloud"} {
		t.Run(model, func(t *testing.T) {
			t.Setenv("ENABLE_CLAUDEAI_MCP_SERVERS", "true")
			t.Setenv("OLLAMA_HOST", "http://127.0.0.1:12345")
			t.Setenv("ANTHROPIC_API_KEY", "test-api-key")
			t.Setenv("ANTHROPIC_AUTH_TOKEN", "test-auth-token")
			t.Setenv("CLAUDE_CODE_PROVIDER_MANAGED_BY_HOST", "0")
			providerKeys := []string{
				"CLAUDE_CODE_USE_BEDROCK", "CLAUDE_CODE_USE_VERTEX", "CLAUDE_CODE_USE_FOUNDRY",
				"CLAUDE_CODE_USE_ANTHROPIC_AWS", "CLAUDE_CODE_USE_ANTHROPIC_GOOGLE_CLOUD", "CLAUDE_CODE_USE_MANTLE",
				"CLAUDE_CODE_USE_GATEWAY",
			}
			for _, key := range providerKeys {
				t.Setenv(key, "1")
			}
			t.Setenv("CLAUDE_CODE_EFFORT_LEVEL", "high")
			t.Setenv("MAX_THINKING_TOKENS", "4096")

			dir := t.TempDir()
			output := filepath.Join(dir, "env-and-args")
			t.Setenv("PATH", dir)
			t.Setenv("CLAUDE_LAUNCH_TEST_OUTPUT", output)
			script := `#!/bin/sh
printf '%s\n' "$ENABLE_CLAUDEAI_MCP_SERVERS" "$ANTHROPIC_BASE_URL" "${ANTHROPIC_API_KEY-unset}" "$ANTHROPIC_AUTH_TOKEN" "$@" > "$CLAUDE_LAUNCH_TEST_OUTPUT"
printf '%s\n' "$CLAUDE_CODE_PROVIDER_MANAGED_BY_HOST" "$CLAUDE_CODE_USE_BEDROCK" "$CLAUDE_CODE_USE_VERTEX" "$CLAUDE_CODE_USE_FOUNDRY" "$CLAUDE_CODE_USE_ANTHROPIC_AWS" "$CLAUDE_CODE_USE_ANTHROPIC_GOOGLE_CLOUD" "$CLAUDE_CODE_USE_MANTLE" "$CLAUDE_CODE_USE_GATEWAY" "$CLAUDE_CODE_EFFORT_LEVEL" "$MAX_THINKING_TOKENS" >> "$CLAUDE_LAUNCH_TEST_OUTPUT"
`
			if err := os.WriteFile(filepath.Join(dir, "claude"), []byte(script), 0o755); err != nil {
				t.Fatal(err)
			}

			mcpConfig := filepath.Join(dir, "mcp.json")
			if err := (&Claude{}).Run(model, nil, []string{"--mcp-config", mcpConfig}); err != nil {
				t.Fatal(err)
			}
			got, err := os.ReadFile(output)
			if err != nil {
				t.Fatal(err)
			}
			want := strings.Join([]string{
				"false", "http://127.0.0.1:12345", "", "ollama", "--model", model, "--mcp-config", mcpConfig,
				"1", "", "", "", "", "", "", "", "high", "4096", "",
			}, "\n")
			if string(got) != want {
				t.Fatalf("child environment and arguments = %q, want %q", got, want)
			}
			if got := os.Getenv("ENABLE_CLAUDEAI_MCP_SERVERS"); got != "true" {
				t.Fatalf("parent ENABLE_CLAUDEAI_MCP_SERVERS = %q, want true", got)
			}
			for _, key := range providerKeys {
				if got := os.Getenv(key); got != "1" {
					t.Errorf("parent %s = %q, want 1", key, got)
				}
			}
			if got := os.Getenv("ANTHROPIC_API_KEY"); got != "test-api-key" {
				t.Errorf("parent ANTHROPIC_API_KEY = %q, want test-api-key", got)
			}
		})
	}
}

func TestClaudeRunAutoModeServer(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("uses a POSIX shell fake binary")
	}

	for _, model := range []string{"llama3.2", "glm-5:cloud"} {
		for _, tt := range []struct {
			name  string
			value string
			unset bool
			want  string
		}{
			{name: "default", unset: true, want: "0"},
			{name: "disabled", value: "0", want: "0"},
			{name: "enabled", value: "1", want: "1"},
			{name: "empty", value: "", want: ""},
		} {
			t.Run(model+"/"+tt.name, func(t *testing.T) {
				t.Setenv("CLAUDE_CODE_AUTO_MODE_SERVER", tt.value)
				if tt.unset {
					if err := os.Unsetenv("CLAUDE_CODE_AUTO_MODE_SERVER"); err != nil {
						t.Fatal(err)
					}
				}

				dir := t.TempDir()
				output := filepath.Join(dir, "env-and-args")
				t.Setenv("PATH", dir)
				t.Setenv("CLAUDE_LAUNCH_TEST_OUTPUT", output)
				script := `#!/bin/sh
printf '%s\n' "${CLAUDE_CODE_AUTO_MODE_SERVER-unset}" "$ANTHROPIC_DEFAULT_SONNET_MODEL" "$@" > "$CLAUDE_LAUNCH_TEST_OUTPUT"
`
				if err := os.WriteFile(filepath.Join(dir, "claude"), []byte(script), 0o755); err != nil {
					t.Fatal(err)
				}

				if err := (&Claude{}).Run(model, nil, []string{"--permission-mode", "auto"}); err != nil {
					t.Fatal(err)
				}
				got, err := os.ReadFile(output)
				if err != nil {
					t.Fatal(err)
				}
				want := strings.Join([]string{tt.want, model, "--model", model, "--permission-mode", "auto", ""}, "\n")
				if string(got) != want {
					t.Fatalf("child environment and arguments = %q, want %q", got, want)
				}
			})
		}
	}
}

func TestClaudeModelEnvVars(t *testing.T) {
	c := &Claude{}

	windowKeys := []string{"CLAUDE_CODE_MAX_CONTEXT_TOKENS", "CLAUDE_CODE_AUTO_COMPACT_WINDOW"}
	t.Setenv("CLAUDE_CODE_AUTO_COMPACT_WINDOW", "")

	envMap := func(envs []string) map[string]string {
		m := make(map[string]string)
		for _, e := range envs {
			k, v, _ := strings.Cut(e, "=")
			m[k] = v
		}
		return m
	}

	t.Run("maps all Claude model env vars to the provided model", func(t *testing.T) {
		got := envMap(c.modelEnvVars("llama3.2", nil))
		if got["ANTHROPIC_DEFAULT_OPUS_MODEL"] != "llama3.2" {
			t.Errorf("OPUS = %q, want llama3.2", got["ANTHROPIC_DEFAULT_OPUS_MODEL"])
		}
		if got["ANTHROPIC_DEFAULT_SONNET_MODEL"] != "llama3.2" {
			t.Errorf("SONNET = %q, want llama3.2", got["ANTHROPIC_DEFAULT_SONNET_MODEL"])
		}
		if got["ANTHROPIC_DEFAULT_HAIKU_MODEL"] != "llama3.2" {
			t.Errorf("HAIKU = %q, want llama3.2", got["ANTHROPIC_DEFAULT_HAIKU_MODEL"])
		}
		if got["CLAUDE_CODE_SUBAGENT_MODEL"] != "llama3.2" {
			t.Errorf("SUBAGENT = %q, want llama3.2", got["CLAUDE_CODE_SUBAGENT_MODEL"])
		}
		for _, key := range windowKeys {
			if v, ok := got[key]; ok {
				t.Errorf("%s = %q, want unset for local models", key, v)
			}
		}
	})

	t.Run("supports empty model", func(t *testing.T) {
		got := envMap(c.modelEnvVars("", nil))
		if got["ANTHROPIC_DEFAULT_OPUS_MODEL"] != "" {
			t.Errorf("OPUS = %q, want empty", got["ANTHROPIC_DEFAULT_OPUS_MODEL"])
		}
		if got["ANTHROPIC_DEFAULT_SONNET_MODEL"] != "" {
			t.Errorf("SONNET = %q, want empty", got["ANTHROPIC_DEFAULT_SONNET_MODEL"])
		}
		if got["ANTHROPIC_DEFAULT_HAIKU_MODEL"] != "" {
			t.Errorf("HAIKU = %q, want empty", got["ANTHROPIC_DEFAULT_HAIKU_MODEL"])
		}
		if got["CLAUDE_CODE_SUBAGENT_MODEL"] != "" {
			t.Errorf("SUBAGENT = %q, want empty", got["CLAUDE_CODE_SUBAGENT_MODEL"])
		}
		for _, key := range windowKeys {
			if v, ok := got[key]; ok {
				t.Errorf("%s = %q, want unset", key, v)
			}
		}
	})

	t.Run("sets context and auto compact windows for known cloud models", func(t *testing.T) {
		for model, want := range map[string]string{
			"glm-5:cloud":     "202752",
			"kimi-k2.6:cloud": "262144",
		} {
			got := envMap(c.modelEnvVars(model, nil))
			for _, key := range windowKeys {
				if got[key] != want {
					t.Errorf("%s: %s = %q, want %s", model, key, got[key], want)
				}
			}
		}
	})

	t.Run("keeps the auto compact window within Claude Code's range", func(t *testing.T) {
		setDynamicCloudModelLimits(map[string]cloudModelLimit{"tiny": {Context: 65_536}})
		t.Cleanup(func() { setDynamicCloudModelLimits(nil) })
		for _, tt := range []struct {
			model       LaunchModel
			wantContext string
			wantCompact string
		}{
			{model: LaunchModel{Name: "nemotron-3-nano:30b:cloud"}, wantContext: "1048576", wantCompact: "1000000"},
			{model: LaunchModel{Name: "tiny:cloud"}, wantContext: "65536"},
			{model: LaunchModel{Name: "new-large:cloud", ContextLength: 1_048_576}, wantContext: "1048576", wantCompact: "1000000"},
			{model: LaunchModel{Name: "new-small:cloud", ContextLength: 65_536}, wantContext: "65536"},
		} {
			got := envMap(c.modelEnvVars(tt.model.Name, []LaunchModel{tt.model}))
			if got["CLAUDE_CODE_MAX_CONTEXT_TOKENS"] != tt.wantContext || got["CLAUDE_CODE_AUTO_COMPACT_WINDOW"] != tt.wantCompact {
				t.Errorf("%s: context = %q, compact = %q; want %q, %q", tt.model.Name, got["CLAUDE_CODE_MAX_CONTEXT_TOKENS"], got["CLAUDE_CODE_AUTO_COMPACT_WINDOW"], tt.wantContext, tt.wantCompact)
			}
		}
	})

	t.Run("keeps the user's auto compact window but not their context window", func(t *testing.T) {
		t.Setenv("CLAUDE_CODE_AUTO_COMPACT_WINDOW", "150000")
		t.Setenv("CLAUDE_CODE_MAX_CONTEXT_TOKENS", "150000")
		got := envMap(c.modelEnvVars("kimi-k2.6:cloud", nil))
		if v, ok := got["CLAUDE_CODE_AUTO_COMPACT_WINDOW"]; ok {
			t.Errorf("AUTO_COMPACT_WINDOW = %q, want left to the user's setting", v)
		}
		if got["CLAUDE_CODE_MAX_CONTEXT_TOKENS"] != "262144" {
			t.Errorf("MAX_CONTEXT_TOKENS = %q, want 262144", got["CLAUDE_CODE_MAX_CONTEXT_TOKENS"])
		}
	})

	t.Run("resolved cloud metadata takes precedence over fallback", func(t *testing.T) {
		t.Setenv("CLAUDE_CODE_AUTO_COMPACT_WINDOW", "")
		models := []LaunchModel{{Name: "kimi-k2.6:cloud", ContextLength: 524288}}
		env := c.modelEnvVars("kimi-k2.6:cloud", models)
		got := envMap(env)
		for _, key := range windowKeys {
			count := 0
			for _, entry := range env {
				if strings.HasPrefix(entry, key+"=") {
					count++
				}
			}
			if got[key] != "524288" || count != 1 {
				t.Errorf("%s = %q (%d entries), want 524288 once", key, got[key], count)
			}
		}
	})

	t.Run("does not set windows for unknown cloud models", func(t *testing.T) {
		got := envMap(c.modelEnvVars("unknown-model:cloud", nil))
		for _, key := range windowKeys {
			if v, ok := got[key]; ok {
				t.Errorf("%s = %q, want unset", key, v)
			}
		}
	})
}

func TestClaudeRunCloudContextWindow(t *testing.T) {
	if runtime.GOOS == "windows" {
		t.Skip("uses a POSIX shell fake binary")
	}

	dir := t.TempDir()
	output := filepath.Join(dir, "context")
	t.Setenv("PATH", dir)
	t.Setenv("CLAUDE_LAUNCH_TEST_OUTPUT", output)
	t.Setenv("CLAUDE_CODE_MAX_CONTEXT_TOKENS", "12345")
	t.Setenv("CLAUDE_CODE_AUTO_COMPACT_WINDOW", "150000")
	script := `#!/bin/sh
printf '%s\n' "$CLAUDE_CODE_MAX_CONTEXT_TOKENS" "$CLAUDE_CODE_AUTO_COMPACT_WINDOW" > "$CLAUDE_LAUNCH_TEST_OUTPUT"
`
	if err := os.WriteFile(filepath.Join(dir, "claude"), []byte(script), 0o755); err != nil {
		t.Fatal(err)
	}

	for _, tt := range []struct {
		name  string
		model LaunchModel
		want  string
	}{
		{name: "cloud model absent from fallback table", model: LaunchModel{Name: "muse-spark-open:cloud", ContextLength: 1048576}, want: "1048576"},
		{name: "remote model without cloud suffix", model: LaunchModel{Name: "custom-cloud", Remote: true, ContextLength: 262144}, want: "262144"},
		{name: "local trained maximum is not the allocated context", model: LaunchModel{Name: "qwen3:8b", ContextLength: 131072}, want: "12345"},
	} {
		t.Run(tt.name, func(t *testing.T) {
			models := []LaunchModel{{Name: "other:cloud", ContextLength: 65536}, tt.model}
			if err := (&Claude{}).Run(tt.model.Name, models, nil); err != nil {
				t.Fatal(err)
			}
			got, err := os.ReadFile(output)
			if err != nil {
				t.Fatal(err)
			}
			if want := tt.want + "\n150000\n"; string(got) != want {
				t.Fatalf("child context settings = %q, want %q", got, want)
			}
		})
	}
}

func TestClaudeModelOutputTokens(t *testing.T) {
	const outputKey = "CLAUDE_CODE_MAX_OUTPUT_TOKENS"
	for _, tt := range []struct {
		name     string
		model    LaunchModel
		override string
		set      bool
		want     string
	}{
		{name: "client ceiling", model: LaunchModel{Name: "large:cloud", ContextLength: 1_048_576, MaxOutputTokens: 393_216}, want: "128000"},
		{name: "model ceiling overrides fallback", model: LaunchModel{Name: "qwen3.5:cloud", ContextLength: 262_144, MaxOutputTokens: 16_384}, want: "16384"},
		{name: "remote alias", model: LaunchModel{Name: "custom-cloud", Remote: true, ContextLength: 262_144, MaxOutputTokens: 64_000}, want: "64000"},
		{name: "fallback limit", model: LaunchModel{Name: "qwen3.5:cloud"}, want: "32768"},
		{name: "unknown limit", model: LaunchModel{Name: "unknown:cloud", ContextLength: 262_144}},
		{name: "local model", model: LaunchModel{Name: "local", ContextLength: 262_144, MaxOutputTokens: 65_536}},
		{name: "explicit override", model: LaunchModel{Name: "large:cloud", ContextLength: 1_048_576, MaxOutputTokens: 393_216}, override: "64000", set: true},
		{name: "explicit empty override", model: LaunchModel{Name: "large:cloud", ContextLength: 1_048_576, MaxOutputTokens: 393_216}, set: true},
	} {
		t.Run(tt.name, func(t *testing.T) {
			t.Setenv(outputKey, tt.override)
			if !tt.set {
				if err := os.Unsetenv(outputKey); err != nil {
					t.Fatal(err)
				}
			}

			env := (&Claude{}).modelEnvVars(tt.model.Name, []LaunchModel{tt.model})
			var got string
			var count int
			for _, entry := range env {
				key, value, _ := strings.Cut(entry, "=")
				if key == outputKey {
					got = value
					count++
				}
				if key == "CLAUDE_CODE_EFFORT_LEVEL" || key == "MAX_THINKING_TOKENS" {
					t.Errorf("unexpected thinking override: %s", entry)
				}
			}
			wantCount := 0
			if tt.want != "" {
				wantCount = 1
			}
			if got != tt.want || count != wantCount {
				t.Errorf("%s = %q (%d entries), want %q (%d entries)", outputKey, got, count, tt.want, wantCount)
			}
		})
	}
}
