package compatmigrate

import (
	"strings"
)

type olmo3Migrator struct{}

// Mirrors the olmo3 arch gate for handle_olmo3 in llama/compat/llama-ollama-compat.cpp; keep the two in sync.
func (olmo3Migrator) NeedsMigration(src *SourceModel) bool {
	return src.GGUF.KeyValue("general.architecture").String() == "olmo3"
}

func (olmo3Migrator) Migrate(src *SourceModel) (*Result, error) {
	tensors, err := readAllSourceTensors(src)
	if err != nil {
		return nil, err
	}

	modelTensors := make([]*outTensor, 0, len(tensors))
	for _, tensor := range tensors {
		modelTensors = append(modelTensors, copyTensor(tensor.name, tensor))
	}

	modelKV := outKV{}
	for _, keyValue := range src.GGUF.KeyValues() {
		if !keyValue.Valid() {
			continue
		}

		key := keyValue.Key
		value := normalizeGGUFValue(keyValue.Any())
		switch {
		case key == "general.architecture":
			modelKV[key] = "olmo2"
		case strings.HasPrefix(key, "olmo3."):
			modelKV["olmo2."+strings.TrimPrefix(key, "olmo3.")] = value
		case strings.HasPrefix(key, "general."), strings.HasPrefix(key, "tokenizer."):
			modelKV[key] = value
		}
	}
	if _, ok := modelKV["general.architecture"]; !ok {
		modelKV["general.architecture"] = "olmo2"
	}

	return &Result{
		ModelKV:      modelKV,
		ModelTensors: modelTensors,
	}, nil
}
